

#2021-11-22
#edit 2025-03-02

import sys, re, json, time
import hashlib,os,codecs
from sqlite3 import dbapi2 as database
import xbmc, xbmcplugin
from resources.lib.control import py2_encode, translatePath, executebuiltin
from resources.lib import log_utils, control, playcountDB, playback_settings, provider_logins, watch_progress

try:
    import xmlrpclib as _xmlrpclib
    from StringIO import StringIO as _io
except:
    import xmlrpc.client as _xmlrpclib
    from io import BytesIO as _io

# eventuell zur spÃ¤teren verwendung als meta
#_params = dict(parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

PLAYBACK_START_TIMEOUT = 45
PLAYBACK_STALL_TIMEOUT = 90
ANDROID_NAVIGATION_RESTORE_DELAY = 8
CONTAINER_IDLE_TIMEOUT = 18


def _addon_enabled(addon_id):
    try:
        payload = json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.GetAddonDetails",
            "params": {"addonid": addon_id, "properties": ["enabled"]},
        })
        response = json.loads(xbmc.executeJSONRPC(payload) or "{}")
        if response.get("error"):
            return bool(control.condVisibility('System.HasAddon(%s)' % addon_id))
        return bool(response.get("result", {}).get("addon", {}).get("enabled"))
    except Exception:
        try:
            return bool(control.condVisibility('System.HasAddon(%s)' % addon_id))
        except Exception:
            return False


class player(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.totalTime = 0
        self.currentTime = 0
        self.playcount = 0
        self.watcher_control = False
        self.playback_started = False
        self.list_position = 0
        self.list_content = ''
        self.queue_playback = False
        self.queue_last = False
        self.playback_failed = False
        self.restore_navigation_pending = False
        self.restore_position_pending = False
        self._last_container_restore_updated = False
        self.isdebug = True if control.getSetting('status.debug') == 'true' else False


    def run(self, title, url, meta):
        import xbmc
        try:
            self.meta = control.sanitizeMetaArtwork(meta)
            meta = self.meta
            self.mediatype = meta['mediatype']
            self.title = meta['title']
            self.year = str(meta['year']) if 'year' in meta else ''
            if meta['mediatype'] == 'movie':
                self.name = title + ' (%s)' % meta['year'] if meta.get('year', False) else title
            else:
                self.name = title + ' S%02dE%02d' % (int(meta['season']), int(meta['episode']))
            self.playback_name = self._playbackLabel(self.name, meta)

            if control.is_python2 and type(self.name) != unicode:
                self.name = self.name.decode('utf-8')
            if control.is_python2 and type(self.playback_name) != unicode:
                self.playback_name = self.playback_name.decode('utf-8')
            self.imdb = meta.get('imdb_id') or meta.get('imdbnumber') or meta.get('imdb')
            self.number_of_seasons = meta['number_of_seasons'] if 'number_of_seasons' in meta else None
            self.season = meta['season'] if 'season' in meta else None
            self.number_of_episodes = meta['number_of_episodes'] if 'number_of_episodes' in meta else None
            self.episode = meta['episode'] if 'episode' in meta else None

            self.playcount = meta['playcount'] if 'playcount' in meta else 0
            self.list_position = int(meta.get('_xvault_list_position', 0) or 0)
            self.list_content = meta.get('_xvault_list_content', '')
            self.container_path = meta.get('_xvault_container_path', '')
            self.queue_playback = bool(meta.get('_xvault_queue_playback', False))
            self.queue_last = bool(meta.get('_xvault_queue_last', False))
            self.offset = bookmarks().get(self.name, self.year)

            from glob import glob
            os.chdir(os.path.join(control.translatePath('special://database/')))
            self.videoDB = os.path.join(control.translatePath('special://database/'), sorted(glob("MyVideos*.db"), reverse=True)[0])

            self.fileID = self.getVideoDB()

            plot = control.unquote(meta['plot']) if 'plot' in meta else ''

            Info = {'plot': plot}
            Info.setdefault('Title', self.playback_name)
            if self.imdb:
                Info.setdefault('IMDBNumber', self.imdb)
            if meta['mediatype'] == 'movie':
                if meta.get('title'):
                    Info.setdefault('OriginalTitle', meta['title'])
                if meta.get('year'):
                    Info.setdefault('year', meta['year'])
            else:
                if meta.get('title'):
                    Info.setdefault('TVshowtitle', meta['title'])
                if self.season != None:
                    Info.setdefault('Season', self.season)
                if self.episode != None:
                    Info.setdefault('Episode', self.episode)

            item = control.item(label=self.playback_name)

            # TS: video/mp2t
            # HLS: application/x-mpegURL or application/vnd.apple.mpegurl
            # Dash: application/dash+xml
            kodiver = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
            stream_probe_url = url.split('|', 1)[0].split('?', 1)[0].lower()
            is_hls_manifest = ".m3u" in stream_probe_url or re.search(r'/playlist/\d+(?:/|$)', stream_probe_url) != None
            is_dash_manifest = '.mpd' in stream_probe_url
            if is_hls_manifest or is_dash_manifest:
                adaptive_enabled = _addon_enabled("inputstream.adaptive")
                if not adaptive_enabled and is_dash_manifest:
                    log_utils.log('DASH playback requested without enabled InputStream Adaptive', log_utils.LOGWARNING)
                if adaptive_enabled:
                    item.setProperty("inputstream", "inputstream.adaptive")
                    if is_dash_manifest:
                        if kodiver < 21: item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                        item.setMimeType('application/dash+xml')
                    else:
                        if kodiver < 21: item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                        # item.setMimeType("application/vnd.apple.mpegurl")
                        item.setMimeType('application/x-mpegURL')
                else:
                    item.setMimeType('application/dash+xml' if is_dash_manifest else 'application/x-mpegURL')
                item.setContentLookup(False)
                if adaptive_enabled and '|' in url:
                    original_url = url
                    stream_url, strhdr = url.split('|', 1)
                    item.setProperty('inputstream.adaptive.common_headers', strhdr)
                    item.setProperty('inputstream.adaptive.stream_headers', strhdr)
                    if kodiver > 19: item.setProperty('inputstream.adaptive.manifest_headers', strhdr)
                    # Vixcloud lehnt Kodis ersten Manifest-Zugriff ohne die Pipe-Header ab.
                    url = original_url if self._needsManifestHeadersInPath(stream_url) else stream_url

            item.setPath(url)
            try:
                item.setArt({'poster': control.posterArtwork(meta.get('poster'), meta.get('cover_url'))})
                item.setInfo(type='Video', infoLabels=Info)
            except:
                pass
            item.setProperty('IsPlayable', 'true')

            if int(sys.argv[1]) > 0:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            else:
                xbmc.Player().play(url, item)
            return self.keepPlaybackAlive()
        except Exception as e:
            log_utils.log('Playback start failed: %s' % str(e), log_utils.LOGERROR)
            return False

    def _playbackLabel(self, name, meta):
        try:
            hoster = self._cleanStreamDisplay(meta.get('_xvault_stream_hoster'))
            provider = self._cleanStreamDisplay(meta.get('_xvault_stream_provider'))
            if hoster and provider and hoster.lower() != provider.lower():
                return '%s | %s @ %s' % (name, hoster, provider)
            if hoster:
                return '%s | %s' % (name, hoster)
            if provider:
                return '%s | %s' % (name, provider)
        except:
            pass
        return name

    def _cleanStreamDisplay(self, value):
        if value == None:
            return ''
        value = re.sub(r'\[[^\]]+\]', '', str(value))
        return re.sub(r'\s+', ' ', value).strip()


    def _needsManifestHeadersInPath(self, stream_url):
        try:
            return re.search(r'^https?://(?:www\.)?vixcloud\.co/playlist/\d+(?:[/?#]|$)', str(stream_url).lower()) != None
        except:
            return False


    def _telemetryPayload(self, error_group=None):
        payload = {
            'media_type': getattr(self, 'mediatype', 'unknown'),
            'playback_mode': playback_settings.get_mode(),
        }
        if error_group:
            payload['error_group'] = error_group
        return payload


    def _telemetryEvent(self, event_name, error_group=None):
        try:
            from resources.lib import telemetry
            telemetry.event(event_name, 'playback', self._telemetryPayload(error_group))
        except:
            pass


    def keepPlaybackAlive(self):
        if self.isdebug: log_utils.log('Start - keepPlaybackAlive', log_utils.LOGINFO)
        started = False
        for i in range(0, PLAYBACK_START_TIMEOUT):
            if self.streamFinished:
                break
            if self.isPlayingVideo():
                started = True
                self.playback_started = True
                break
            control.sleep(1)

        if not started:
            self.playback_failed = True
            self._closePlaybackBusyDialogs()
            self._stopFailedPlayback()
            log_utils.log(
                'Playback start timeout nach %s Sekunden: %s' %
                (PLAYBACK_START_TIMEOUT, getattr(self, 'playback_name', getattr(self, 'name', 'unbekannt'))),
                log_utils.LOGWARNING
            )
            self._telemetryEvent('playback_failed', 'player_timeout')
            return False

        try:
            playcountDB.createEntry(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode)
        except:
            pass

        monitor = xbmc.Monitor()
        self.watcher_control = False
        stopped_without_callback = 0
        last_position = -1.0
        last_progress_at = time.time()
        while (not monitor.abortRequested()) & (not self.streamFinished):
            if self.isPlayingVideo():
                stopped_without_callback = 0
                self.totalTime = self.getTotalTime()
                self.currentTime = self.getTime()
                if self._isPlaybackPaused():
                    last_progress_at = time.time()
                elif self.currentTime > last_position + 0.25:
                    last_position = self.currentTime
                    last_progress_at = time.time()
                elif time.time() - last_progress_at >= PLAYBACK_STALL_TIMEOUT:
                    self.playback_failed = True
                    self.streamFinished = True
                    log_utils.log(
                        'Playback ohne Fortschritt abgebrochen nach %s Sekunden: %s' %
                        (PLAYBACK_STALL_TIMEOUT, getattr(self, 'playback_name', '')),
                        log_utils.LOGWARNING
                    )
                    self._telemetryEvent('playback_failed', 'player_stall')
                    self._closePlaybackBusyDialogs()
                    self._stopFailedPlayback()
                    break
                watcher = watch_progress.is_completed_position(self.currentTime, self.totalTime)
                if watcher and not self.watcher_control:
                    playcountDB.updatePlaycount(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode, 1)
                    #control.setSetting(id='watcher.control', value='true')
                    self.watcher_control = True
            else:
                stopped_without_callback += 1
                if stopped_without_callback >= 5:
                    log_utils.log('Playback ohne Stop-Callback beendet: %s' % getattr(self, 'playback_name', ''), log_utils.LOGWARNING)
                    self._finishPlayback(True, playback_ended=False)
                    break
            monitor.waitForAbort(3)

        self._runDeferredNavigationRestore()
        if self.isdebug: log_utils.log('Ende - keepPlaybackAlive', log_utils.LOGINFO)
        return not self.playback_failed

    def _closePlaybackBusyDialogs(self):
        try:
            control.execute('Dialog.Close(busydialog,true)')
            control.execute('Dialog.Close(busydialognocancel,true)')
            control.idle()
        except:
            pass

    def _stopFailedPlayback(self):
        try:
            if self.isPlaying():
                self.stop()
        except:
            try:
                xbmc.Player().stop()
            except:
                pass

    def _isPlaybackPaused(self):
        try:
            return bool(control.condVisibility('Player.Paused'))
        except:
            return False


    def idleForPlayback(self):
        for i in range(0, 200):
            if control.condVisibility('Window.IsActive(busydialog)') == 1: control.idle()
            else: break
            control.sleep(1)


    def onAVStarted(self):
        if self.isdebug: log_utils.log('Start - onAVStarted', log_utils.LOGINFO)
        self.playback_started = True
        self._telemetryEvent('playback_started')
        control.execute('Dialog.Close(all,true)')
        if not self.offset == '0': self.seekTime(float(self.offset))
        self.idleForPlayback()
        if control.getSetting('subtitles') == 'true':
            subtitles().get(self.name, self.imdb, self.season, self.episode)
            # Subtitles in Player MenÃ¼ ausschalten - wird dann bei Bedarf per "Hand" eingeschaltet
            # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": 1, "subtitle" : "on"}, "id": "1"}')
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": 1, "subtitle" : "off"}, "id": "1"}')
        self._traktStart()
        if self.isdebug: log_utils.log('Ende - onAVStarted', log_utils.LOGINFO)

    def onPlayBackPaused(self):
        self._traktPause()

    def onPlayBackResumed(self):
        self._traktStart()

    def onPlayBackStopped(self):
        self._finishPlayback(True, playback_ended=False)

    def onPlayBackEnded(self):
        self._finishPlayback(not self.queue_playback or self.queue_last, playback_ended=True)
        if self.isdebug: log_utils.log('Ende - onPlayBackEnded', log_utils.LOGINFO)

    def onPlayBackError(self):
        log_utils.log('Playback-Fehler vor oder waehrend der Wiedergabe: %s' % getattr(self, 'playback_name', ''), log_utils.LOGWARNING)
        self.playback_failed = True
        self._telemetryEvent('playback_failed', 'player_error')
        self._closePlaybackBusyDialogs()
        self.streamFinished = True

    def _finishPlayback(self, restore_navigation, playback_ended=False):
        if self.streamFinished:
            return
        if not self.playback_started:
            self.streamFinished = True
            return
        if self.isdebug: log_utils.log('Start - onPlayBackStopped', log_utils.LOGINFO)
        self.runVideoDB()
        self.streamFinished = True
        completed = self._completed(playback_ended)
        if completed:
            self.currentTime = self.totalTime if self.totalTime else self.currentTime
            if not self.watcher_control:
                self._markWatched()
            self.watcher_control = True
        self._telemetryEvent('playback_completed' if completed else 'playback_stopped')
        bookmarks().reset(self.currentTime, self.totalTime, self.name, self.year)
        try:
            from resources.lib.sync import binge_sync
            binge_sync.record_playback(self.meta, self.name, self.year, self.currentTime, self.totalTime, completed=completed, push=True)
        except:
            pass
        try:
            from resources.lib import trakt
            trakt.record_playback(self.meta, self.currentTime, self.totalTime, completed=completed)
        except:
            pass
        if restore_navigation:
            if self.isdebug: log_utils.log('vor parentDir - onPlayBackStopped', log_utils.LOGINFO)
            self.restore_navigation_pending = True
            self.restore_position_pending = self._shouldRestoreListPosition()
        self.watcher_control = False
        if self.isdebug: log_utils.log('Ende - onPlayBackStopped', log_utils.LOGINFO)

    def _shouldRestoreListPosition(self):
        if self.list_position <= 0:
            return False
        if self.mediatype != 'movie' and control.getSetting('status.position') == 'true':
            return False
        return True


    def _restoreSourceContainer(self):
        self._last_container_restore_updated = False
        path = str(getattr(self, 'container_path', '') or '').strip()
        if not self._isSafeXvaultContainerPath(path):
            if self.isdebug:
                log_utils.log(__name__ + ' - sichere Container-Rueckkehr ohne gueltigen xVAULT-Pfad uebersprungen', log_utils.LOGINFO)
            return False

        try:
            if self._isAndroidPlatform() and not self._waitForContainerNavigationIdle(0.5, 10):
                if self.isdebug:
                    log_utils.log(__name__ + ' - Android Container-Rueckkehr uebersprungen: Kodi noch nicht idle', log_utils.LOGWARNING)
                return False

            current_path = control.getInfoLabel('Container.FolderPath') or ''
            if current_path == path:
                return True

            control.execute('Container.Update(%s,replace)' % path)
            self._last_container_restore_updated = True
            expected_content = self.list_content or ('movies' if self.mediatype == 'movie' else 'episodes')
            for count in range(1, 25 + 1):
                control.sleep(0.5)
                current_path = control.getInfoLabel('Container.FolderPath') or ''
                current_content = control.getInfoLabel('Container.Content') or ''
                if current_path == path:
                    return True
                if expected_content and current_content == expected_content:
                    return True

            if self.isdebug:
                log_utils.log(__name__ + ' - Container-Rueckkehr nicht bestaetigt: %s' % path, log_utils.LOGWARNING)
        except Exception as exc:
            if self.isdebug:
                log_utils.log(__name__ + ' - Container-Rueckkehr fehlgeschlagen: %s' % str(exc), log_utils.LOGWARNING)
        return False


    def _isSafeXvaultContainerPath(self, path):
        if not path:
            return False
        lowered = path.lower()
        return lowered.startswith('plugin://plugin.video.xvault/') or lowered.startswith('plugin://plugin.video.xvault?')

    def _isAndroidPlatform(self):
        try:
            return bool(control.condVisibility('System.Platform.Android'))
        except:
            return False

    def _waitForContainerNavigationIdle(self, initial_delay=0, timeout=CONTAINER_IDLE_TIMEOUT):
        try:
            monitor = xbmc.Monitor()
            if initial_delay:
                if monitor.waitForAbort(initial_delay):
                    return False

            deadline = time.time() + timeout
            stable_checks = 0
            while time.time() < deadline and not monitor.abortRequested():
                busy = False
                try:
                    busy = self.isPlaying() or \
                        bool(control.condVisibility('Window.IsActive(fullscreenvideo)')) or \
                        bool(control.condVisibility('Window.IsActive(busydialog)')) or \
                        bool(control.condVisibility('Window.IsActive(busydialognocancel)')) or \
                        bool(control.condVisibility('Container.IsUpdating'))
                except:
                    busy = True

                if busy:
                    stable_checks = 0
                else:
                    stable_checks += 1
                    if stable_checks >= 3:
                        return True
                monitor.waitForAbort(0.5)
        except:
            pass
        return False


    def _runDeferredNavigationRestore(self):
        if not getattr(self, 'restore_navigation_pending', False):
            return
        self.restore_navigation_pending = False
        delay = ANDROID_NAVIGATION_RESTORE_DELAY if self._isAndroidPlatform() else 1
        if not self._waitForContainerNavigationIdle(delay, CONTAINER_IDLE_TIMEOUT):
            if self.isdebug:
                log_utils.log(__name__ + ' - Navigation nach Playback-Ende uebersprungen: Kodi noch nicht idle', log_utils.LOGWARNING)
            self.restore_position_pending = False
            return
        try:
            self.parentDir()
        finally:
            if getattr(self, 'restore_position_pending', False):
                try:
                    from resources.lib.utils import restoreListPosition
                    restoreListPosition(self.list_position, self.list_content, __name__)
                except:
                    pass
            self.restore_position_pending = False


    def _completed(self, playback_ended=False):
        if playback_ended:
            return True
        if self.watcher_control:
            return True
        try:
            return watch_progress.is_completed_position(self.currentTime, self.totalTime)
        except:
            return False


    def _markWatched(self):
        try:
            playcountDB.createEntry(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode)
            playcountDB.updatePlaycount(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode, 1)
        except:
            pass


    def _traktStart(self):
        try:
            from resources.lib import trakt
            trakt.scrobble_start(self.meta, self._safePlayerTime(), self._safePlayerTotal())
        except:
            pass


    def _traktPause(self):
        try:
            from resources.lib import trakt
            trakt.scrobble_pause(self.meta, self._safePlayerTime(), self._safePlayerTotal())
        except:
            pass


    def _safePlayerTime(self):
        try:
            self.currentTime = self.getTime()
        except:
            pass
        return self.currentTime


    def _safePlayerTotal(self):
        try:
            self.totalTime = self.getTotalTime()
        except:
            pass
        return self.totalTime


    def parentDir(self):
        refreshtime = 2
        restored_container_update = False
        control.sleep(refreshtime)
        ccont = ''
        if playback_settings.get_mode() == '1': # Liste der Streams (Hosterliste) als Verzeichnis
            count = 0
            # prÃ¼fen ob Hosterliste aktiv ist - content ist da 'videos'
            for count in range(1, 25+1):
                control.sleep(2)
                ccont = control.getInfoLabel("Container.Content")
                if ccont == 'videos': break

            if self.isdebug: log_utils.log(__name__ + ' - count: %s - Container.Content (1):  %s' % (count, control.getInfoLabel("Container.Content")), log_utils.LOGINFO)
            if count == 25: return

            # zur Film- bzw. Episodenliste wechseln  - von content 'videos' dann zu content 'videos'
            if control.getInfoLabel("Container.Content") != 'movies' and ccont == 'videos':
                if self._restoreSourceContainer():
                    refreshtime = 0
                    restored_container_update = bool(getattr(self, '_last_container_restore_updated', False))
                elif self.isdebug:
                    log_utils.log(__name__ + ' - unsichere ParentDir-Navigation nach Playback-Ende uebersprungen', log_utils.LOGWARNING)

        if self.playcount == 0:
            ## auch abhÃ¤ngig von control.content()
            refresh = False
            if control.getSetting('status.refresh.movies') == 'true' and self.mediatype == 'movie': # immer!
                refresh = True
            elif control.getSetting('status.refresh.episodes') == 'true' and self.mediatype != 'movie':
                refresh = True

            if refresh:
                if restored_container_update:
                    if self.isdebug:
                        log_utils.log(__name__ + ' - zusaetzlicher Container.Refresh nach Container.Update uebersprungen', log_utils.LOGINFO)
                    return
                if refreshtime != 0: control.sleep(refreshtime)
                self.refreshContainer()


    def refreshContainer(self):
        if self._isAndroidPlatform() and not self._waitForContainerNavigationIdle(0, 12):
            if self.isdebug:
                log_utils.log(__name__ + ' - Container.Refresh uebersprungen: Kodi noch nicht idle', log_utils.LOGWARNING)
            return
        if self.mediatype != 'movie':
            if not self._isSafeXvaultContainerPath(self.container_path):
                if self.isdebug:
                    log_utils.log(__name__ + ' - Container.Refresh fuer ungueltigen Serienpfad uebersprungen', log_utils.LOGINFO)
                return
            control.execute('Container.Update(%s,replace)' % self.container_path)
            return
        control.execute('Container.Refresh')

# keine EintrÃ¤ge fÃ¼r bookmarks und files in die Kodi DB 'MyVideos116.db' anlegen bzw. sofort lÃ¶schen
    def runVideoDB(self):
        idFile = self.getVideoDB()
        if idFile != self.fileID:
            self.removeVideoDB(idFile)

    def getVideoDB(self):
        dbcon = database.connect(self.videoDB)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM files")
        match = dbcur.fetchall()
        dbcon.close()
        if match and len(match) > 0: idFile = len(match)
        else: idFile = 0
        return idFile

    def removeVideoDB(self, idFile):
        dbcon = database.connect(self.videoDB)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM files WHERE idFile = '%s'" % idFile) # in DB vorhandener Trigger lÃ¶scht auch den bookmark
        dbcon.commit()
        dbcon.close()


class subtitles:
    def __init__(self, *args, **kwargs):
        __scriptname__ = "XBMC Subtitles Login"
        __version__ = control.addonVersion  # Module version
        BASE_URL_XMLRPC = u"http://api.opensubtitles.org/xml-rpc"

        self.server = _xmlrpclib.ServerProxy(BASE_URL_XMLRPC, verbose=0)
        os_user, os_pass = provider_logins.get_credentials('opensubtitles')
        login = self.server.LogIn(os_user, os_pass, "en", "%s_v%s" % (__scriptname__.replace(" ", "_"), __version__))
        if login["status"] == "200 OK":
            self.osdb_token = login["token"]

    def get(self, name, imdb, season, episode):
        season = str(season)
        episode = str(episode)
        try:
            langDict = {'Afrikaans': 'afr', 'Albanian': 'alb', 'Arabic': 'ara', 'Armenian': 'arm', 'Basque': 'baq', 'Bengali': 'ben', 'Bosnian': 'bos', 'Breton': 'bre', 'Bulgarian': 'bul', 'Burmese': 'bur', 'Catalan': 'cat', 'Chinese': 'chi', 'Croatian': 'hrv', 'Czech': 'cze', 'Danish': 'dan', 'Dutch': 'dut', 'English': 'eng', 'Esperanto': 'epo', 'Estonian': 'est', 'Finnish': 'fin', 'French': 'fre', 'Galician': 'glg', 'Georgian': 'geo', 'German': 'ger', 'Greek': 'ell', 'Hebrew': 'heb', 'Hindi': 'hin', 'Hungarian': 'hun', 'Icelandic': 'ice', 'Indonesian': 'ind', 'Italian': 'ita', 'Japanese': 'jpn', 'Kazakh': 'kaz', 'Khmer': 'khm', 'Korean': 'kor', 'Latvian': 'lav', 'Lithuanian': 'lit', 'Luxembourgish': 'ltz', 'Macedonian': 'mac', 'Malay': 'may', 'Malayalam': 'mal', 'Manipuri': 'mni', 'Mongolian': 'mon', 'Montenegrin': 'mne', 'Norwegian': 'nor', 'Occitan': 'oci', 'Persian': 'per', 'Polish': 'pol', 'Portuguese': 'por,pob', 'Portuguese(Brazil)': 'pob,por', 'Romanian': 'rum', 'Russian': 'rus', 'Serbian': 'scc', 'Sinhalese': 'sin', 'Slovak': 'slo', 'Slovenian': 'slv', 'Spanish': 'spa', 'Swahili': 'swa', 'Swedish': 'swe', 'Syriac': 'syr', 'Tagalog': 'tgl', 'Tamil': 'tam', 'Telugu': 'tel', 'Thai': 'tha', 'Turkish': 'tur', 'Ukrainian': 'ukr', 'Urdu': 'urd'}
            codePageDict = {'ara': 'cp1256', 'ar': 'cp1256', 'ell': 'cp1253', 'el': 'cp1253', 'heb': 'cp1255', 'he': 'cp1255', 'tur': 'cp1254', 'tr': 'cp1254', 'rus': 'cp1251', 'ru': 'cp1251'}

            # opensubtitles.org
            os_user, os_pass = provider_logins.get_credentials('opensubtitles')
            os_useragent = 'TemporaryUserAgent'

            langs = []
            try:
                try: langs = langDict[control.getSetting('subtitles.lang.1')].split(',')
                except: langs.append(langDict[control.getSetting('subtitles.lang.1')])
            except: pass

            try:
                try: langs = langs + langDict[control.getSetting('subtitles.lang.2')].split(',')
                except: langs.append(langDict[control.getSetting('subtitles.lang.2')])
            except: pass

            try: subLang = xbmc.Player().getSubtitles()
            except: subLang = ''
            if subLang == langs[0]: raise Exception()

            imdbid = re.sub(r'[^0-9]', '', imdb)
            if season == 'None' or episode == 'None':
                result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[0], 'imdbid': imdbid}])['data']
                if result == []: result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[1], 'imdbid': imdbid}])['data']
            else:
                result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[0], 'imdbid': imdbid, 'season': season, 'episode': episode}])['data']
                if result == []: result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[1], 'imdbid': imdbid, 'season': season, 'episode': episode}])['data']
                # fmt = ['hdtv']

            filter = []
            result = [i for i in result if i['SubSumCD'] == '1']

            for userrank in ['OS Legend','Administrator','Translator','Platinum member','Gold member','Silver member', 'Bronze member','trusted','']:
                for i in result:
                    if i['UserRank'] == userrank.lower():
                        filter.append(i)

            try: lang = xbmc.convertLanguage(filter[0]['SubLanguageID'], xbmc.ISO_639_1)
            except: lang = filter[0]['SubLanguageID']

            subtitle = control.translatePath('special://temp/')
            subtitle = os.path.join(subtitle, 'TemporarySubs.%s.srt' % lang)

            ZipDownloadID = filter[0]['ZipDownloadLink'].split('/')[-1]
            ZipDownloadLink = 'https://dl.opensubtitles.org/en/download/sub/%s' % ZipDownloadID

            import requests, zipfile

            r = requests.get(ZipDownloadLink)
            zf = zipfile.ZipFile(_io(r.content))
            content = ''
            for name in zf.namelist():
                if not name.endswith('.srt'): continue
                content = zf.read(name)

            codepage = codePageDict.get(lang, '')
            if codepage and control.getSetting('subtitles.utf') == 'true':
                try:
                    content_encoded = codecs.decode(content, codepage)
                    content = codecs.encode(content_encoded, 'utf-8')
                except:
                    pass

            output = open(subtitle, 'wb')
            output.write(content)
            output.close()

            control.sleep(1)
            xbmc.Player().setSubtitles(subtitle)
        except:
            pass


class bookmarks:
    def get(self, name, year='0'):
        from resources.lib import bookmarkDB
        offset = '0'
        try:
            if not control.getSetting('bookmarks') == 'true': raise Exception()

            idFile = hashlib.md5()
            for i in name:
                try:
                    idFile.update(str(i).encode('utf-8'))
                except:
                    idFile.update(str(i))
            for i in year:
                try:
                    idFile.update(str(i).encode('utf-8'))
                except:
                    idFile.update(str(i))
            idFile = str(idFile.hexdigest())

            match = bookmarkDB.get_query(idFile, 'bookmarks.pcl')

            # dbcon = database.connect(control.bookmarksFile)
            # dbcur = dbcon.cursor()
            # dbcur.execute("CREATE TABLE IF NOT EXISTS bookmark (""idFile TEXT, ""timeInSeconds TEXT, ""UNIQUE(idFile)"");")
            # dbcur.execute("SELECT * FROM bookmark WHERE idFile = '%s'" % idFile)
            # match = dbcur.fetchone()
            # dbcon.commit()
            # dbcon.close()

            if match: self.offset = str(match[1])
            if self.offset == '0': raise Exception()
            minutes, seconds = divmod(float(self.offset), 60)
            hours, minutes = divmod(minutes, 60)
            label = '%02d:%02d:%02d' % (hours, minutes, seconds)
            label = py2_encode("Fortsetzen ab : %s" % label)

            if control.getSetting('bookmarks.auto') == 'false':
                try:
                    yes = control.dialog.contextmenu([label, "Vom Anfang abspielen", ])
                except:
                    yes = control.yesnoDialog(label, '', '', str(name), "Fortsetzen",
                                              "Vom Anfang abspielen")
                if yes:
                    bookmarkDB.remove_query(idFile, 'bookmarks')
                    self.offset = '0'

            return self.offset
        except:
            return offset


    def reset(self, currentTime, totalTime, name, year='0'):
        from resources.lib import bookmarkDB
        try:
            #if not control.getSetting('bookmarks') == 'true': raise Exception()
            if control.getSetting('bookmarks') == 'true' and int(currentTime) > 180:
                timeInSeconds = str(currentTime)
                idFile = hashlib.md5()
                for i in name:
                    try:
                        idFile.update(str(i).encode('utf-8'))
                    except:
                        idFile.update(str(i))
                for i in year:
                    try:
                        idFile.update(str(i).encode('utf-8'))
                    except:
                        idFile.update(str(i))
                idFile = str(idFile.hexdigest())

                if watch_progress.is_completed_position(currentTime, totalTime):
                    bookmarkDB.remove_query(idFile, 'bookmarks')
                elif watch_progress.should_store_resume(currentTime, totalTime):
                    bookmarkDB.save_query(idFile, timeInSeconds, 'bookmarks')

                # dbcon = database.connect(control.bookmarksFile)
                # dbcur = dbcon.cursor()
                # dbcur.execute("CREATE TABLE IF NOT EXISTS bookmark (""idFile TEXT, ""timeInSeconds TEXT, ""UNIQUE(idFile)"");")
                # if (currentTime / totalTime) <= .92:
                #     dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
                #     dbcur.execute("INSERT INTO bookmark Values (?, ?)", (idFile, timeInSeconds))
                # else:
                #     dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
                # dbcon.commit()
                # dbcon.close()

        except:
            pass

