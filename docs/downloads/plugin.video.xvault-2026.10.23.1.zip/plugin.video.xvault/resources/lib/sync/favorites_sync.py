import hashlib
import json
import os
import time
import xml.etree.ElementTree as ET

import xbmcvfs

from resources.lib import control, log_utils
from resources.lib.sync import device, storage
from resources.lib.sync.api_client import ApiError, Client


STATE_FILE = 'sync_favorites_state.json'
REMOTE_PULL_INTERVAL = 30
REMOTE_DIFFERENCE_NOTICE = 'remote_difference_notice'
REMOTE_DIFFERENCE_NOTICE_AT = 'remote_difference_notice_at'


def favourites_path():
    return control.translatePath('special://profile/favourites.xml')


def read_favourites():
    path = favourites_path()
    if not os.path.exists(path):
        return ''
    with open(path, 'r', encoding='utf-8-sig') as handle:
        return handle.read()


def favorites_hash(raw_xml=None):
    raw = read_favourites() if raw_xml is None else raw_xml
    normalized = raw.replace('\r\n', '\n').strip().encode('utf-8')
    return hashlib.sha256(normalized).hexdigest()


def collect(raw_xml=None, deleted_keys=None, base_keys=None):
    raw = read_favourites() if raw_xml is None else raw_xml
    items = []
    if raw.strip():
        try:
            for index, item in enumerate(_parse_entries(raw), 1):
                path_text = item['path']
                items.append({
                    'order': index,
                    'label': item['label'],
                    'thumb': item['thumb'],
                    'path': path_text,
                    'type': 'video' if _is_xvault_path(path_text) else 'unknown',
                })
        except Exception as exc:
            log_utils.log('xVAULT sync: failed to parse favourites.xml: %s' % exc, log_utils.LOGWARNING)
    digest = favorites_hash(raw)
    payload = {
        'schema_version': 1,
        'source': 'kodi_favourites',
        'addon': control.addonId,
        'device_id': device.get_device_id(),
        'updated_at': iso_now(),
        'favorites_hash': digest,
        'raw_xml': raw,
        'items': items,
    }
    if deleted_keys:
        payload['deleted_keys'] = sorted(set(deleted_keys))
    if base_keys is not None:
        payload['base_keys'] = list(base_keys)
    return payload


def _is_xvault_path(path_text):
    return 'plugin.video.xvault' in path_text or 'plugin.video.xvaultalpha' in path_text


def check_and_push_if_changed(silent=True, client=None, require_enabled=True, force=False, raise_errors=False, active=False):
    if require_enabled and (not storage.is_enabled() or not storage.is_logged_in()):
        return False
    if not require_enabled and client is None and not storage.is_logged_in():
        return False
    client = client or Client()
    try:
        from resources.lib.sync import engine
        return engine.synchronize(client=client, active=active)
    except ApiError as exc:
        if exc.code == 'UNAUTHORIZED':
            _handle_unauthorized()
        if raise_errors:
            raise
        if not silent:
            control.infoDialog(str(exc), icon='WARNING')
        return False
    except Exception as exc:
        log_utils.log('xVAULT sync: device exchange pending: %s' % exc, log_utils.LOGWARNING)
        if raise_errors:
            raise
        return False


def _handle_unauthorized():
    try:
        storage.clear_login()
        log_utils.log('xVAULT sync: favorites auth rejected, login cleared', log_utils.LOGWARNING)
    except Exception as exc:
        log_utils.log('xVAULT sync: failed to clear rejected login: %s' % exc, log_utils.LOGWARNING)


def _sync_favorites_delta(silent=True, client=None, force=False):
    local_raw = read_favourites()
    local_hash = favorites_hash(local_raw)
    state = load_state()
    base_revision = _state_revision(state)
    local_entries = _delta_entries(local_raw)
    upserts, deletes = _local_delta(local_entries, state)

    data = client.sync_favorites_delta(
        base_revision=base_revision,
        upserts=upserts,
        deletes=deletes,
        local_hash=local_hash,
    )
    changes = data.get('changes') or []
    if not isinstance(changes, list):
        changes = []

    merged_raw = local_raw
    if changes:
        merged_entries = _apply_delta_changes(local_entries, changes)
        merged_raw = _build_xml(merged_entries)
        if favorites_hash(merged_raw) != local_hash:
            write_favourites(merged_raw, backup=True)
            local_raw = merged_raw
            local_hash = favorites_hash(local_raw)

    revision = int(data.get('revision') or base_revision or 0)
    mark_delta_synced(local_raw, revision)
    storage.update_last_sync(iso_now())
    storage.set_status('Angemeldet als %s' % storage.email())
    if not silent and (force or upserts or deletes or changes):
        control.infoDialog('Favoriten synchronisiert.', icon='INFO')
    return bool(force or upserts or deletes or changes)


def _should_use_legacy_favorites_sync(exc):
    return exc.status == 404 or exc.code in ('INVALID_ACTION', 'UNKNOWN_ACTION', 'ACTION_NOT_FOUND', 'NOT_FOUND')


def _sync_favorites_full(silent=True, client=None, force=False):
    local_raw = read_favourites()
    local_hash = favorites_hash(local_raw)

    server_raw = ''
    server_available = False
    try:
        data = client.pull_favorites()
        favorites = data.get('favorites') or {}
        server_raw = _payload_raw_xml(favorites)
        server_available = True
    except ApiError as exc:
        if exc.code != 'NO_BACKUP_FOUND':
            if not silent:
                control.infoDialog(str(exc), icon='WARNING')
            return False

    server_hash = favorites_hash(server_raw) if server_available else ''
    if server_available and server_hash != local_hash:
        notify_remote_difference_once(local_hash, server_hash)

    merged_raw, deleted_keys = merge_favorites_with_deleted(local_raw, server_raw, deletion_aware=True)
    merged_hash = favorites_hash(merged_raw)

    if not force and local_hash == storage.get_setting(storage.LAST_FAVORITES_HASH) and (not server_available or merged_hash == server_hash):
        return False

    if server_available and merged_hash == server_hash:
        mark_local_synced(local_raw, server_raw)
        storage.update_last_sync(iso_now())
        storage.set_status('Angemeldet als %s' % storage.email())
        return False

    try:
        client.push_favorites(collect(merged_raw, deleted_keys=deleted_keys))
        mark_local_synced(local_raw, merged_raw)
        storage.update_last_sync(iso_now())
        storage.set_status('Angemeldet als %s' % storage.email())
        if not silent:
            control.infoDialog('Favoriten wurden gesichert.', icon='INFO')
        return True
    except ApiError as exc:
        if not silent:
            control.infoDialog(str(exc), icon='WARNING')
        return False


def restore_from_server(mode='ask', client=None, require_login=True):
    from resources.lib.sync import engine
    if engine.synchronize(client=client):
        control.infoDialog('Aktueller Kontostand übernommen. Offene Konflikte unter Geräte & Sync-Verlauf prüfen.', icon='INFO')
    return


def merge_favorites(local_xml, server_xml, deletion_aware=False):
    merged_raw, _deleted_keys = merge_favorites_with_deleted(local_xml, server_xml, deletion_aware=deletion_aware)
    return merged_raw


def merge_favorites_with_deleted(local_xml, server_xml, deletion_aware=False):
    local_entries = _dedupe_entries(_parse_entries(local_xml))
    server_entries = _dedupe_entries(_parse_entries(server_xml))
    removed = set()
    if deletion_aware:
        last_keys = set(load_state().get('keys') or [])
        if last_keys:
            local_keys = set(_entry_key(item) for item in local_entries)
            server_keys = set(_entry_key(item) for item in server_entries)
            removed = (last_keys - local_keys) | (last_keys - server_keys)
    return _build_xml(_combine_entries(local_entries, server_entries, removed)), removed


def _parse_entries(raw):
    if not raw or not raw.strip():
        return []
    try:
        root = ET.fromstring(raw.encode('utf-8'))
    except Exception:
        return []
    result = []
    for node in root.findall('favourite'):
        result.append({
            'label': node.attrib.get('name', ''),
            'thumb': node.attrib.get('thumb', ''),
            'path': (node.text or '').strip(),
        })
    return result


def _payload_raw_xml(payload):
    raw = payload.get('raw_xml', '') if isinstance(payload, dict) else ''
    if raw:
        return raw
    items = payload.get('items', []) if isinstance(payload, dict) else []
    if not isinstance(items, list):
        return ''
    entries = []
    for item in items:
        if not isinstance(item, dict):
            continue
        entries.append({
            'label': item.get('label', ''),
            'thumb': item.get('thumb', ''),
            'path': item.get('path', ''),
        })
    return _build_xml(_dedupe_entries(entries))


def _entry_key(item):
    return (item.get('path') or item.get('label') or '').strip()


def _dedupe_entries(entries):
    result = []
    seen = set()
    for item in entries:
        key = _entry_key(item)
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result


def _combine_entries(local_entries, server_entries, removed=None):
    removed = removed or set()
    entries = []
    seen = set()
    for item in list(local_entries) + list(server_entries):
        key = _entry_key(item)
        if not key or key in removed or key in seen:
            continue
        seen.add(key)
        entries.append(item)
    return entries


def _build_xml(entries):
    root = ET.Element('favourites')
    for item in entries:
        node = ET.SubElement(root, 'favourite')
        if item.get('label'):
            node.set('name', item['label'])
        if item.get('thumb'):
            node.set('thumb', item['thumb'])
        node.text = item.get('path', '')
    return ET.tostring(root, encoding='unicode') + '\n'


def _state_revision(state):
    try:
        return max(0, int(state.get('remote_revision') or 0))
    except Exception:
        return 0


def _state_items(state):
    items = state.get('items') if isinstance(state, dict) else {}
    if not isinstance(items, dict):
        return {}
    result = {}
    for key, value in items.items():
        key = str(key or '').strip().lower()
        if not key:
            continue
        if isinstance(value, dict):
            result[key] = value
        else:
            result[key] = {'hash': str(value or '')}
    return result


def _entry_key_hash(item):
    key = _entry_key(item)
    return hashlib.sha256(key.encode('utf-8')).hexdigest() if key else ''


def _entry_hash(item, order):
    data = {
        'label': item.get('label', '') or '',
        'thumb': item.get('thumb', '') or '',
        'path': item.get('path', '') or '',
        'order': int(order or 0),
    }
    raw = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def _delta_entries(raw_xml=None):
    entries = []
    for order, item in enumerate(_dedupe_entries(_parse_entries(raw_xml if raw_xml is not None else read_favourites())), 1):
        key = _entry_key_hash(item)
        if not key:
            continue
        entry = {
            'key': key,
            'order': order,
            'label': item.get('label', '') or '',
            'thumb': item.get('thumb', '') or '',
            'path': item.get('path', '') or '',
        }
        entry['hash'] = _entry_hash(entry, order)
        entries.append(entry)
    return entries


def _delta_payload(entry):
    return {
        'key': entry.get('key', ''),
        'order': int(entry.get('order') or 0),
        'label': entry.get('label', '') or '',
        'thumb': entry.get('thumb', '') or '',
        'path': entry.get('path', '') or '',
    }


def _local_delta(entries, state):
    previous = _state_items(state)
    current = {entry['key']: entry for entry in entries if entry.get('key')}
    if not previous:
        return [_delta_payload(entry) for entry in entries], []

    upserts = []
    for key, entry in current.items():
        old = previous.get(key) or {}
        if old.get('hash') != entry.get('hash'):
            upserts.append(_delta_payload(entry))

    deletes = [key for key in previous.keys() if key not in current]
    return upserts, deletes


def _delta_entry_from_remote(item):
    if not isinstance(item, dict):
        return None
    path = (item.get('path') or '').strip()
    key = (item.get('key') or '').strip().lower()
    if not key or not path:
        return None
    try:
        order = int(item.get('order') or 0)
    except Exception:
        order = 0
    entry = {
        'key': key,
        'order': max(0, order),
        'label': item.get('label', '') or '',
        'thumb': item.get('thumb', '') or '',
        'path': path,
    }
    entry['hash'] = _entry_hash(entry, entry['order'])
    return entry


def _apply_delta_changes(local_entries, changes):
    active = {entry['key']: dict(entry) for entry in local_entries if entry.get('key')}
    def _revision(change):
        try:
            return int(change.get('revision') or 0)
        except Exception:
            return 0
    for change in sorted([item for item in changes if isinstance(item, dict)], key=_revision):
        key = (change.get('key') or '').strip().lower()
        if not key:
            continue
        if change.get('deleted'):
            active.pop(key, None)
            continue
        entry = _delta_entry_from_remote(change.get('item') or {})
        if entry:
            active[key] = entry
    return _sort_delta_entries(active.values())


def _sort_delta_entries(entries):
    def _sort_key(item):
        try:
            order = int(item.get('order') or 0)
        except Exception:
            order = 0
        return (order if order > 0 else 999999, (item.get('label') or '').lower(), item.get('key') or '')
    return sorted([item for item in entries if item.get('path')], key=_sort_key)


def write_favourites(raw_xml, backup=False):
    if not raw_xml.strip():
        raw_xml = '<favourites />\n'
    if backup:
        backup_current()
    path = favourites_path()
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent)
    with open(path, 'w', encoding='utf-8') as handle:
        handle.write(raw_xml)


def load_state():
    data = storage.read_json(STATE_FILE, {})
    return data if isinstance(data, dict) else {}


def notify_remote_difference_once(local_hash, server_hash):
    notice_key = hashlib.sha256(('%s:%s' % (local_hash, server_hash)).encode('utf-8')).hexdigest()
    state = load_state()
    if state.get(REMOTE_DIFFERENCE_NOTICE) == notice_key:
        return False
    state[REMOTE_DIFFERENCE_NOTICE] = notice_key
    state[REMOTE_DIFFERENCE_NOTICE_AT] = iso_now()
    storage.write_json(STATE_FILE, state)
    control.infoDialog(
        'Favoriten unterscheiden sich zwischen diesem Gerät und dem xVAULT-Server. Lokal wurde nichts geändert.',
        icon='INFO',
        time=7000,
    )
    return True


def mark_delta_synced(raw_xml, remote_revision):
    entries = _delta_entries(raw_xml)
    digest = favorites_hash(raw_xml)
    data = {
        'schema_version': 2,
        'favorites_hash': digest,
        'keys': [_entry_key(item) for item in _parse_entries(raw_xml) if _entry_key(item)],
        'items': dict((entry['key'], {'hash': entry.get('hash', '')}) for entry in entries),
        'remote_revision': int(remote_revision or 0),
        'updated_at': iso_now(),
    }
    storage.write_json(STATE_FILE, data)
    storage.set_setting(storage.LAST_FAVORITES_HASH, digest)


def mark_synced(raw_xml):
    entries = _dedupe_entries(_parse_entries(raw_xml))
    keys = [_entry_key(item) for item in entries if _entry_key(item)]
    digest = favorites_hash(raw_xml)
    storage.write_json(STATE_FILE, {
        'favorites_hash': digest,
        'keys': keys,
        'updated_at': iso_now(),
    })
    storage.set_setting(storage.LAST_FAVORITES_HASH, digest)


def mark_local_synced(local_xml, server_xml=''):
    state = load_state()
    entries = _dedupe_entries(_parse_entries(local_xml))
    keys = [_entry_key(item) for item in entries if _entry_key(item)]
    digest = favorites_hash(local_xml)
    server_hash = favorites_hash(server_xml) if server_xml else ''
    data = {
        'favorites_hash': digest,
        'keys': keys,
        'updated_at': iso_now(),
    }
    if server_hash:
        data['server_favorites_hash'] = server_hash
    if server_hash and server_hash != digest and state.get(REMOTE_DIFFERENCE_NOTICE):
        data[REMOTE_DIFFERENCE_NOTICE] = state.get(REMOTE_DIFFERENCE_NOTICE)
        data[REMOTE_DIFFERENCE_NOTICE_AT] = state.get(REMOTE_DIFFERENCE_NOTICE_AT, '')
    storage.write_json(STATE_FILE, data)
    storage.set_setting(storage.LAST_FAVORITES_HASH, digest)


def has_local_changes():
    if not storage.is_enabled() or not storage.is_logged_in():
        return False
    return favorites_hash() != storage.get_setting(storage.LAST_FAVORITES_HASH)


def monitor_changes(interval=5):
    try:
        import xbmc
        class SyncMonitor(xbmc.Monitor):
            def onNotification(self, sender, method, data):
                if method in ('System.OnWake', 'System.OnScreensaverDeactivated'):
                    from resources.lib.sync import engine
                    engine.on_wake()
        monitor = SyncMonitor()
        from resources.lib.sync import engine
        next_remote_pull = time.time() + REMOTE_PULL_INTERVAL
        next_local_check = 0
        next_attempt = 0
        handled_request = ''
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break
            now = time.time()
            if now < next_attempt:
                continue
            request = engine.background_request()
            requested = bool(request.get('id') and request['id'] != handled_request)
            changed = now >= next_local_check and has_local_changes()
            if now >= next_local_check:
                next_local_check = now + interval
            if requested or changed or now >= next_remote_pull:
                success = check_and_push_if_changed(silent=True, active=requested and request.get('active', False))
                if success and requested:
                    handled_request = request['id']
                next_attempt = time.time() + (1 if success else interval)
                next_remote_pull = time.time() + REMOTE_PULL_INTERVAL
    except Exception as exc:
        log_utils.log('xVAULT sync: favorites monitor stopped: %s' % exc, log_utils.LOGWARNING)


def backup_current():
    raw = read_favourites()
    if not raw:
        return
    backup = favourites_path() + '.xvault-backup-%s' % time.strftime('%Y%m%d%H%M%S')
    with open(backup, 'w', encoding='utf-8') as handle:
        handle.write(raw)


def iso_now():
    return time.strftime('%Y-%m-%dT%H:%M:%S%z')
