<?php
declare(strict_types=1);

const PROBE_TOKEN = 'xv-restore-probe-20260811-0c1e9e646fd9448d9f3d0bb80d8441bb';

if (($_GET['token'] ?? '') !== PROBE_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(120);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): PDO
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    return new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function try_query(PDO $pdo, string $sql): array
{
    try {
        $stmt = $pdo->query($sql);
        return ['ok' => true, 'rows' => $stmt ? $stmt->fetchAll() : []];
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

try {
    $pdo = db();
    $tables = try_query($pdo, 'SHOW TABLES');
    $counts = [];
    foreach (['users', 'favorites_backups', 'binge_state', 'sync_log', 'telemetry_installations', 'telemetry_sessions', 'telemetry_events', 'telemetry_daily_stats'] as $table) {
        $count = try_query($pdo, 'SELECT COUNT(*) AS c FROM `' . str_replace('`', '``', $table) . '`');
        $counts[$table] = $count['ok'] ? (int)($count['rows'][0]['c'] ?? 0) : null;
    }

    echo json_encode([
        'success' => true,
        'tables' => $tables,
        'counts' => $counts,
        'log_bin' => try_query($pdo, "SHOW VARIABLES LIKE 'log_bin'"),
        'binlogs' => try_query($pdo, 'SHOW BINARY LOGS'),
        'grants' => try_query($pdo, 'SHOW GRANTS'),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
