<?php
declare(strict_types=1);

const EMPTY_TOKEN = 'xv-empty-sync-log-20260811-a3b5b455dfd247e1b2fef8edb8425938';

if (($_GET['token'] ?? '') !== EMPTY_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(900);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): array
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    $pdo = new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return [$pdo, $config['db_name'] ?? ''];
}

function row_count(PDO $pdo): int
{
    $row = $pdo->query('SELECT COUNT(*) AS c FROM sync_log')->fetch();
    return (int)($row['c'] ?? 0);
}

function table_size(PDO $pdo, string $dbName): array
{
    $stmt = $pdo->prepare(
        "SELECT TABLE_ROWS AS approx_rows,
                DATA_LENGTH AS data_bytes,
                INDEX_LENGTH AS index_bytes
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'sync_log'"
    );
    $stmt->execute([$dbName]);
    $row = $stmt->fetch() ?: [];
    return [
        'rows' => row_count($pdo),
        'approx_rows' => isset($row['approx_rows']) ? (int)$row['approx_rows'] : null,
        'data_bytes' => isset($row['data_bytes']) ? (int)$row['data_bytes'] : null,
        'index_bytes' => isset($row['index_bytes']) ? (int)$row['index_bytes'] : null,
    ];
}

try {
    [$pdo, $dbName] = db();
    $batchSize = min(50000, max(1000, (int)($_GET['batch'] ?? 20000)));
    $before = table_size($pdo, $dbName);
    $deleted = 0;
    $batches = 0;

    do {
        $stmt = $pdo->prepare('DELETE FROM sync_log LIMIT ' . $batchSize);
        $stmt->execute();
        $count = $stmt->rowCount();
        $deleted += $count;
        if ($count > 0) {
            $batches++;
        }
    } while ($count > 0);

    $optimize = $pdo->query('OPTIMIZE TABLE sync_log')->fetchAll();
    $pdo->query('ANALYZE TABLE sync_log')->fetchAll();
    $after = table_size($pdo, $dbName);

    echo json_encode([
        'success' => true,
        'batch_size' => $batchSize,
        'before' => $before,
        'deleted' => [
            'sync_log' => $deleted,
            'batches' => $batches,
        ],
        'optimize' => $optimize,
        'after' => $after,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
