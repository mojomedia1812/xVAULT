<?php
declare(strict_types=1);

const CLEANUP_TOKEN = 'xv-clean-favorites-20260811-bec4f84719bb4fb3b594aee4579eb0d4';
const BLOCKED_EMAIL_SUFFIX = 'youre.a.nigger.com';

if (($_GET['token'] ?? '') !== CLEANUP_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(600);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): PDO
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    return new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function scalar(PDO $pdo, string $sql): int
{
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch();
    return (int)array_values($row ?: [0])[0];
}

function setup_blocked_users(PDO $pdo): void
{
    $pdo->exec('DROP TEMPORARY TABLE IF EXISTS tmp_blocked_users');
    $pdo->exec('CREATE TEMPORARY TABLE tmp_blocked_users (id INT NOT NULL PRIMARY KEY) ENGINE=MEMORY');
    $stmt = $pdo->prepare('INSERT INTO tmp_blocked_users (id) SELECT id FROM users WHERE LOWER(email) LIKE ?');
    $stmt->execute(['%' . BLOCKED_EMAIL_SUFFIX]);
}

function setup_keep_favorites(PDO $pdo): void
{
    $pdo->exec('DROP TEMPORARY TABLE IF EXISTS tmp_keep_favorites');
    $pdo->exec('CREATE TEMPORARY TABLE tmp_keep_favorites (id INT NOT NULL PRIMARY KEY) ENGINE=MEMORY');
    $pdo->exec(
        "INSERT INTO tmp_keep_favorites (id)
         SELECT fb.id
         FROM favorites_backups fb
         INNER JOIN (
             SELECT user_id,
                    MAX(CONCAT(DATE_FORMAT(updated_at, '%Y%m%d%H%i%s'), LPAD(id, 10, '0'))) AS keep_key
             FROM favorites_backups
             GROUP BY user_id
         ) latest
            ON latest.user_id = fb.user_id
           AND latest.keep_key = CONCAT(DATE_FORMAT(fb.updated_at, '%Y%m%d%H%i%s'), LPAD(fb.id, 10, '0'))"
    );
}

function collect_report(PDO $pdo, string $mode): array
{
    setup_blocked_users($pdo);
    setup_keep_favorites($pdo);

    $totalFavorites = scalar($pdo, 'SELECT COUNT(*) FROM favorites_backups');
    $favoriteUsers = scalar($pdo, 'SELECT COUNT(DISTINCT user_id) FROM favorites_backups');
    $blockedUsers = scalar($pdo, 'SELECT COUNT(*) FROM tmp_blocked_users');
    $blockedFavorites = scalar($pdo, 'SELECT COUNT(*) FROM favorites_backups fb INNER JOIN tmp_blocked_users bu ON bu.id = fb.user_id');
    $blockedBinge = scalar($pdo, 'SELECT COUNT(*) FROM binge_state b INNER JOIN tmp_blocked_users bu ON bu.id = b.user_id');
    $blockedSyncLog = scalar($pdo, 'SELECT COUNT(*) FROM sync_log sl INNER JOIN tmp_blocked_users bu ON bu.id = sl.user_id');
    $keepers = scalar($pdo, 'SELECT COUNT(*) FROM tmp_keep_favorites');
    $oldFavoriteRows = scalar($pdo, 'SELECT COUNT(*) FROM favorites_backups fb LEFT JOIN tmp_keep_favorites k ON k.id = fb.id WHERE k.id IS NULL');

    return [
        'success' => true,
        'mode' => $mode,
        'favorites_before' => $totalFavorites,
        'favorite_users_before' => $favoriteUsers,
        'latest_favorite_rows_to_keep' => $keepers,
        'old_favorite_rows_to_delete' => $oldFavoriteRows,
        'blocked_users_to_delete' => $blockedUsers,
        'blocked_related_rows' => [
            'favorites_backups' => $blockedFavorites,
            'binge_state' => $blockedBinge,
            'sync_log' => $blockedSyncLog,
        ],
    ];
}

try {
    $pdo = db();
    $mode = (string)($_GET['mode'] ?? 'preview');
    if ($mode !== 'execute') {
        echo json_encode(collect_report($pdo, 'preview'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $before = collect_report($pdo, 'execute');
    $startedAt = gmdate('c');

    $deleted = [];
    $pdo->beginTransaction();
    try {
        setup_blocked_users($pdo);

        foreach (['favorites_backups', 'binge_state', 'sync_log'] as $table) {
            $stmt = $pdo->prepare("DELETE t FROM {$table} t INNER JOIN tmp_blocked_users bu ON bu.id = t.user_id");
            $stmt->execute();
            $deleted[$table . '_blocked'] = $stmt->rowCount();
        }

        $stmt = $pdo->prepare('DELETE u FROM users u INNER JOIN tmp_blocked_users bu ON bu.id = u.id');
        $stmt->execute();
        $deleted['users_blocked'] = $stmt->rowCount();

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    setup_keep_favorites($pdo);
    $batchSize = min(5000, max(100, (int)($_GET['batch'] ?? 1000)));
    $deleted['old_favorites'] = 0;
    $deleted['old_favorites_batches'] = 0;
    do {
        $stmt = $pdo->prepare('DELETE FROM favorites_backups WHERE id NOT IN (SELECT id FROM tmp_keep_favorites) LIMIT ' . $batchSize);
        $stmt->execute();
        $count = $stmt->rowCount();
        $deleted['old_favorites'] += $count;
        if ($count > 0) {
            $deleted['old_favorites_batches']++;
        }
    } while ($count > 0);

    $after = collect_report($pdo, 'after');

    echo json_encode([
        'success' => true,
        'started_at' => $startedAt,
        'finished_at' => gmdate('c'),
        'before' => $before,
        'deleted' => $deleted,
        'after' => $after,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
