<?php
declare(strict_types=1);

const OPTIMIZE_TOKEN = 'xv-optimize-favorites-20260811-8d77e12f3b1d4bf591ae57d62d30626c';

if (($_GET['token'] ?? '') !== OPTIMIZE_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(900);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): array
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    $pdo = new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return [$pdo, $config['db_name'] ?? ''];
}

function table_stats(PDO $pdo, string $dbName): array
{
    $stmt = $pdo->prepare(
        "SELECT TABLE_NAME AS name,
                TABLE_ROWS AS approx_rows,
                DATA_LENGTH AS data_bytes,
                INDEX_LENGTH AS index_bytes
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'favorites_backups'"
    );
    $stmt->execute([$dbName]);
    $row = $stmt->fetch() ?: [];
    $count = $pdo->query('SELECT COUNT(*) AS c FROM favorites_backups')->fetch();
    return [
        'rows' => (int)($count['c'] ?? 0),
        'approx_rows' => isset($row['approx_rows']) ? (int)$row['approx_rows'] : null,
        'data_bytes' => isset($row['data_bytes']) ? (int)$row['data_bytes'] : null,
        'index_bytes' => isset($row['index_bytes']) ? (int)$row['index_bytes'] : null,
    ];
}

try {
    [$pdo, $dbName] = db();
    $before = table_stats($pdo, $dbName);
    $optimize = [];
    if (($_GET['mode'] ?? 'stats') === 'optimize') {
        $stmt = $pdo->query('OPTIMIZE TABLE favorites_backups');
        $optimize = $stmt->fetchAll();
        $pdo->query('ANALYZE TABLE favorites_backups')->fetchAll();
    }
    $after = table_stats($pdo, $dbName);
    echo json_encode([
        'success' => true,
        'before' => $before,
        'optimize' => $optimize,
        'after' => $after,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
