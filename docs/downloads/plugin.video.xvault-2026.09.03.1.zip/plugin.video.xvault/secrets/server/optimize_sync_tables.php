<?php
declare(strict_types=1);

const OPTIMIZE_TOKEN = 'xv-optimize-sync-tables-20260811-e61b96e3dff84e46a25b3a18debb6f90';

if (($_GET['token'] ?? '') !== OPTIMIZE_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(900);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): array
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    $pdo = new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return [$pdo, $config['db_name'] ?? ''];
}

function table_stats(PDO $pdo, string $dbName, array $tables): array
{
    $placeholders = implode(',', array_fill(0, count($tables), '?'));
    $stmt = $pdo->prepare(
        "SELECT TABLE_NAME AS name,
                TABLE_ROWS AS approx_rows,
                DATA_LENGTH AS data_bytes,
                INDEX_LENGTH AS index_bytes
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ({$placeholders})"
    );
    $stmt->execute(array_merge([$dbName], $tables));
    $sizeRows = [];
    foreach ($stmt as $row) {
        $sizeRows[(string)$row['name']] = $row;
    }

    $stats = [];
    foreach ($tables as $table) {
        $count = $pdo->query('SELECT COUNT(*) AS c FROM `' . str_replace('`', '``', $table) . '`')->fetch();
        $row = $sizeRows[$table] ?? [];
        $stats[$table] = [
            'rows' => (int)($count['c'] ?? 0),
            'approx_rows' => isset($row['approx_rows']) ? (int)$row['approx_rows'] : null,
            'data_bytes' => isset($row['data_bytes']) ? (int)$row['data_bytes'] : null,
            'index_bytes' => isset($row['index_bytes']) ? (int)$row['index_bytes'] : null,
        ];
    }
    return $stats;
}

try {
    [$pdo, $dbName] = db();
    $tables = ['users', 'favorites_backups', 'binge_state', 'sync_log'];
    $before = table_stats($pdo, $dbName, $tables);
    $results = [];
    if (($_GET['mode'] ?? 'stats') === 'optimize') {
        foreach ($tables as $table) {
            $results[$table] = $pdo->query('OPTIMIZE TABLE `' . str_replace('`', '``', $table) . '`')->fetchAll();
            $pdo->query('ANALYZE TABLE `' . str_replace('`', '``', $table) . '`')->fetchAll();
        }
    }
    $after = table_stats($pdo, $dbName, $tables);
    echo json_encode([
        'success' => true,
        'before' => $before,
        'optimize' => $results,
        'after' => $after,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
