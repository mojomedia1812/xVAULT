<?php
declare(strict_types=1);

const CLEANUP_TOKEN = 'xv-clean-orphan-sync-log-20260811-5bcd0f9f16f84683a766cbbfdc3871a0';

if (($_GET['token'] ?? '') !== CLEANUP_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(900);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): PDO
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    return new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function orphan_count(PDO $pdo): int
{
    $stmt = $pdo->query(
        'SELECT COUNT(*) AS c
         FROM sync_log sl
         LEFT JOIN users u ON u.id = sl.user_id
         WHERE u.id IS NULL'
    );
    $row = $stmt->fetch();
    return (int)($row['c'] ?? 0);
}

function orphan_sample(PDO $pdo): array
{
    $stmt = $pdo->query(
        'SELECT sl.user_id, COUNT(*) AS rows_count, MIN(sl.created_at) AS first_created_at, MAX(sl.created_at) AS last_created_at
         FROM sync_log sl
         LEFT JOIN users u ON u.id = sl.user_id
         WHERE u.id IS NULL
         GROUP BY sl.user_id
         ORDER BY rows_count DESC
         LIMIT 20'
    );
    return $stmt->fetchAll();
}

try {
    $pdo = db();
    $mode = (string)($_GET['mode'] ?? 'preview');
    $batchSize = min(10000, max(100, (int)($_GET['batch'] ?? 5000)));
    $before = [
        'orphan_sync_log_rows' => orphan_count($pdo),
        'sample' => orphan_sample($pdo),
    ];

    $deleted = 0;
    $batches = 0;
    if ($mode === 'execute') {
        do {
            $stmt = $pdo->prepare(
                "DELETE FROM sync_log
                 WHERE user_id NOT IN (SELECT id FROM users)
                 LIMIT {$batchSize}"
            );
            $stmt->execute();
            $count = $stmt->rowCount();
            $deleted += $count;
            if ($count > 0) {
                $batches++;
            }
        } while ($count > 0);
    }

    $after = [
        'orphan_sync_log_rows' => orphan_count($pdo),
        'sample' => orphan_sample($pdo),
    ];

    echo json_encode([
        'success' => true,
        'mode' => $mode,
        'batch_size' => $batchSize,
        'before' => $before,
        'deleted' => [
            'sync_log' => $deleted,
            'batches' => $batches,
        ],
        'after' => $after,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
