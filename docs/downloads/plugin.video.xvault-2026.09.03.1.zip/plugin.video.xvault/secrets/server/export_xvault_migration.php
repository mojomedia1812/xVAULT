<?php
declare(strict_types=1);

const EXPORT_TOKEN = 'xv-migrate-20260811-f4f1f997f35f4ab29dc908f4e5778738';

if (($_GET['token'] ?? '') !== EXPORT_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(300);
ini_set('memory_limit', '512M');
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

try {
    $configFile = __DIR__ . '/config.php';
    if (!is_file($configFile)) {
        $configFile = __DIR__ . '/config.example.php';
    }
    $config = require $configFile;
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    $pdo = new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed',
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function ident(string $name): string
{
    return '`' . str_replace('`', '``', $name) . '`';
}

function table_primary_order(PDO $pdo, string $table): string
{
    $stmt = $pdo->prepare('SHOW KEYS FROM ' . ident($table) . ' WHERE Key_name = ?');
    $stmt->execute(['PRIMARY']);
    $primary = [];
    foreach ($stmt as $row) {
        $primary[] = $row;
    }
    usort($primary, static function (array $a, array $b): int {
        return ((int)($a['Seq_in_index'] ?? 0)) <=> ((int)($b['Seq_in_index'] ?? 0));
    });
    $columns = array_map(static function (array $row): string {
        return ident((string)$row['Column_name']);
    }, $primary);
    return $columns ? implode(', ', $columns) : '1';
}

function table_columns(PDO $pdo, string $table): array
{
    $stmt = $pdo->query('SHOW COLUMNS FROM ' . ident($table));
    return $stmt->fetchAll();
}

function table_indexes(PDO $pdo, string $table): array
{
    $stmt = $pdo->query('SHOW INDEX FROM ' . ident($table));
    return $stmt->fetchAll();
}

function table_create_sql(PDO $pdo, string $table): string
{
    $stmt = $pdo->query('SHOW CREATE TABLE ' . ident($table));
    $row = $stmt->fetch();
    return (string)($row['Create Table'] ?? '');
}

try {
    $tables = [];
    $stmt = $pdo->query('SHOW TABLES');
    foreach ($stmt as $row) {
        $tables[] = array_values($row)[0];
    }
    sort($tables, SORT_STRING);

    $mode = (string)($_GET['mode'] ?? 'all');
    if ($mode === 'meta') {
        $result = [
            'success' => true,
            'exported_at' => gmdate('c'),
            'source' => [
                'host' => $config['db_host'] ?? 'localhost',
                'database' => $config['db_name'] ?? '',
            ],
            'tables' => [],
        ];
        foreach ($tables as $table) {
            $countStmt = $pdo->query('SELECT COUNT(*) AS c FROM ' . ident($table));
            $countRow = $countStmt->fetch();
            $result['tables'][$table] = [
                'columns' => table_columns($pdo, $table),
                'indexes' => table_indexes($pdo, $table),
                'create_sql' => table_create_sql($pdo, $table),
                'row_count' => (int)($countRow['c'] ?? 0),
                'rows' => [],
            ];
        }
        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($mode === 'stats') {
        $result = [
            'success' => true,
            'exported_at' => gmdate('c'),
            'tables' => [],
        ];
        $sizeStmt = $pdo->prepare(
            'SELECT TABLE_NAME AS name, TABLE_ROWS AS approx_rows, DATA_LENGTH AS data_bytes, INDEX_LENGTH AS index_bytes FROM information_schema.TABLES WHERE TABLE_SCHEMA = ?'
        );
        $sizeStmt->execute([$config['db_name'] ?? '']);
        $sizes = [];
        foreach ($sizeStmt as $row) {
            $sizes[(string)$row['name']] = $row;
        }
        $includeTextStats = (string)($_GET['text'] ?? '') === '1';
        foreach ($tables as $table) {
            $countStmt = $pdo->query('SELECT COUNT(*) AS c FROM ' . ident($table));
            $countRow = $countStmt->fetch();
            $result['tables'][$table] = [
                'row_count' => (int)($countRow['c'] ?? 0),
                'data_length' => isset($sizes[$table]) ? (int)$sizes[$table]['data_bytes'] : null,
                'index_length' => isset($sizes[$table]) ? (int)$sizes[$table]['index_bytes'] : null,
                'approx_rows' => isset($sizes[$table]) ? (int)$sizes[$table]['approx_rows'] : null,
            ];
            if ($includeTextStats) {
                foreach (table_columns($pdo, $table) as $column) {
                    $field = (string)($column['Field'] ?? '');
                    $type = strtolower((string)($column['Type'] ?? ''));
                    if ($field !== '' && (strpos($type, 'text') !== false || strpos($type, 'json') !== false)) {
                        $sumStmt = $pdo->query('SELECT COALESCE(SUM(CHAR_LENGTH(' . ident($field) . ')), 0) AS bytes FROM ' . ident($table));
                        $sumRow = $sumStmt->fetch();
                        $result['tables'][$table]['text_bytes_' . $field] = (int)($sumRow['bytes'] ?? 0);
                    }
                }
            }
        }
        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($mode === 'chunk') {
        $table = (string)($_GET['table'] ?? '');
        if (!in_array($table, $tables, true)) {
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => 'Unknown table',
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }
        $offset = max(0, (int)($_GET['offset'] ?? 0));
        $limit = min(1000, max(1, (int)($_GET['limit'] ?? 250)));
        $orderBy = table_primary_order($pdo, $table);
        $stmt = $pdo->query('SELECT * FROM ' . ident($table) . ' ORDER BY ' . $orderBy . ' LIMIT ' . $limit . ' OFFSET ' . $offset);
        $rows = [];
        foreach ($stmt as $row) {
            $rows[] = $row;
        }
        echo json_encode([
            'success' => true,
            'table' => $table,
            'offset' => $offset,
            'limit' => $limit,
            'count' => count($rows),
            'rows' => $rows,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $result = [
        'success' => true,
        'exported_at' => gmdate('c'),
        'source' => [
            'host' => $config['db_host'] ?? 'localhost',
            'database' => $config['db_name'] ?? '',
        ],
        'tables' => [],
    ];

    foreach ($tables as $table) {
        $orderBy = table_primary_order($pdo, $table);
        $rows = [];
        $stmt = $pdo->query('SELECT * FROM ' . ident($table) . ' ORDER BY ' . $orderBy);
        foreach ($stmt as $row) {
            $rows[] = $row;
        }
        $result['tables'][$table] = [
            'columns' => table_columns($pdo, $table),
            'indexes' => table_indexes($pdo, $table),
            'create_sql' => table_create_sql($pdo, $table),
            'row_count' => count($rows),
            'rows' => $rows,
        ];
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Export failed',
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
