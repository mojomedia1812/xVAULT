<?php
return [
    'db_host' => 'sql312.infinityfree.com',
    'db_name' => 'if0_41919664_xvault',
    'db_user' => 'if0_41919664',
    'db_pass' => 'tedepo57',
    'timezone' => 'Europe/Berlin',
    'cors_origin' => '',
];