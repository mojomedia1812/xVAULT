<?php
return [
    'db_host' => 'localhost',
    'db_name' => 'mardeg88_xvault',
    'db_user' => 'mardeg88_xvault',
    'db_pass' => 'tedepo57',
    'timezone' => 'Europe/Berlin',
    'cors_origin' => '',
];
