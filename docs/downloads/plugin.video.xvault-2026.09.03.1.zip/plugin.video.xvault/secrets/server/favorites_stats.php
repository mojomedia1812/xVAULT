<?php
declare(strict_types=1);

const STATS_TOKEN = 'xv-fav-stats-20260811-99d6f9f9a51b4c9d8e9656c11c3b83e0';

if (($_GET['token'] ?? '') !== STATS_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(180);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

try {
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    $pdo = new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    $summary = $pdo->query(
        'SELECT COUNT(*) AS total_rows,
                COUNT(DISTINCT user_id) AS distinct_users,
                COUNT(DISTINCT data_hash) AS distinct_hashes,
                MIN(id) AS min_id,
                MAX(id) AS max_id,
                MIN(created_at) AS first_created_at,
                MAX(created_at) AS last_created_at
         FROM favorites_backups'
    )->fetch();

    $topUsers = $pdo->query(
        'SELECT user_id,
                COUNT(*) AS rows_count,
                COUNT(DISTINCT data_hash) AS distinct_hashes,
                MIN(created_at) AS first_created_at,
                MAX(created_at) AS last_created_at
         FROM favorites_backups
         GROUP BY user_id
         ORDER BY rows_count DESC
         LIMIT 10'
    )->fetchAll();

    $topHashes = $pdo->query(
        'SELECT data_hash,
                COUNT(*) AS rows_count,
                MIN(created_at) AS first_created_at,
                MAX(created_at) AS last_created_at
         FROM favorites_backups
         GROUP BY data_hash
         ORDER BY rows_count DESC
         LIMIT 10'
    )->fetchAll();

    $latestSample = $pdo->query(
        'SELECT id, user_id, device_id, data_hash, CHAR_LENGTH(data_json) AS json_chars, created_at
         FROM favorites_backups
         ORDER BY id DESC
         LIMIT 20'
    )->fetchAll();

    $firstSample = $pdo->query(
        'SELECT id, user_id, device_id, data_hash, CHAR_LENGTH(data_json) AS json_chars, created_at
         FROM favorites_backups
         ORDER BY id ASC
         LIMIT 20'
    )->fetchAll();

    $probeRows = [];
    $minId = (int)($summary['min_id'] ?? 0);
    $maxId = (int)($summary['max_id'] ?? 0);
    if ($minId > 0 && $maxId >= $minId) {
        $stmt = $pdo->prepare(
            'SELECT id, user_id, CHAR_LENGTH(data_json) AS json_chars, created_at
             FROM favorites_backups
             WHERE id >= ?
             ORDER BY id ASC
             LIMIT 1'
        );
        for ($i = 0; $i <= 20; $i++) {
            $probeId = (int)round($minId + (($maxId - $minId) * ($i / 20)));
            $stmt->execute([$probeId]);
            $row = $stmt->fetch();
            if ($row) {
                $probeRows[] = $row;
            }
        }
    }

    echo json_encode([
        'success' => true,
        'summary' => $summary,
        'top_users' => $topUsers,
        'top_hashes' => $topHashes,
        'latest_sample' => $latestSample,
        'first_sample' => $firstSample,
        'id_probe_sample' => $probeRows,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
