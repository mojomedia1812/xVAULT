<?php
declare(strict_types=1);

const CLEANUP_TOKEN = 'xv-clean-users-email-age-20260811-6d5f1d59a9f94d5c9a8bb92db5c11ee4';
const AGE_DAYS = 14;

if (($_GET['token'] ?? '') !== CLEANUP_TOKEN) {
    http_response_code(403);
    echo 'forbidden';
    exit;
}

set_time_limit(900);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');

function db(): PDO
{
    $config = require __DIR__ . '/config.php';
    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=utf8mb4',
        $config['db_host'] ?? 'localhost',
        $config['db_name'] ?? ''
    );
    return new PDO($dsn, $config['db_user'] ?? '', $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
}

function scalar(PDO $pdo, string $sql): int
{
    $stmt = $pdo->query($sql);
    $row = $stmt->fetch();
    return (int)array_values($row ?: [0])[0];
}

function load_last_map(PDO $pdo, string $sql): array
{
    $map = [];
    $stmt = $pdo->query($sql);
    foreach ($stmt as $row) {
        $map[(int)$row['user_id']] = (string)$row['last_at'];
    }
    return $map;
}

function impossible_email_domain(string $email): bool
{
    $email = strtolower(trim($email));
    if ($email === '' || substr_count($email, '@') !== 1 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return true;
    }

    [, $domain] = explode('@', $email, 2);
    $domain = trim($domain, " \t\n\r\0\x0B.");
    if ($domain === '' || strpos($domain, '.') === false || strlen($domain) > 253) {
        return true;
    }
    if (strpos($domain, '..') !== false || preg_match('/[^a-z0-9.-]/', $domain)) {
        return true;
    }

    $labels = explode('.', $domain);
    foreach ($labels as $label) {
        if ($label === '' || strlen($label) > 63) {
            return true;
        }
        if (!preg_match('/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/', $label)) {
            return true;
        }
    }

    $tld = end($labels);
    if (!is_string($tld) || strlen($tld) < 2 || strlen($tld) > 63 || !preg_match('/^[a-z]+$/', $tld)) {
        return true;
    }

    $reservedTlds = ['example' => true, 'invalid' => true, 'localhost' => true, 'test' => true];
    if (isset($reservedTlds[$tld])) {
        return true;
    }

    $reservedDomains = [
        'example.com' => true,
        'example.net' => true,
        'example.org' => true,
        'localhost.localdomain' => true,
    ];
    if (isset($reservedDomains[$domain])) {
        return true;
    }

    return false;
}

function max_datetime(array $values): ?string
{
    $max = null;
    foreach ($values as $value) {
        if ($value === null || $value === '') {
            continue;
        }
        $value = (string)$value;
        if ($max === null || $value > $max) {
            $max = $value;
        }
    }
    return $max;
}

function prepare_candidates(PDO $pdo): array
{
    $cutoff = (new DateTimeImmutable('now'))->modify('-' . AGE_DAYS . ' days')->format('Y-m-d H:i:s');
    $favoriteLast = load_last_map($pdo, 'SELECT user_id, MAX(updated_at) AS last_at FROM favorites_backups GROUP BY user_id');
    $bingeLast = load_last_map($pdo, 'SELECT user_id, MAX(updated_at) AS last_at FROM binge_state GROUP BY user_id');
    $syncLast = load_last_map($pdo, 'SELECT user_id, MAX(created_at) AS last_at FROM sync_log GROUP BY user_id');

    $pdo->exec('DROP TEMPORARY TABLE IF EXISTS tmp_cleanup_users');
    $pdo->exec('CREATE TEMPORARY TABLE tmp_cleanup_users (id INT NOT NULL PRIMARY KEY, reason VARCHAR(32) NOT NULL) ENGINE=MEMORY');

    $insert = $pdo->prepare('INSERT INTO tmp_cleanup_users (id, reason) VALUES (?, ?) ON DUPLICATE KEY UPDATE reason = CONCAT(reason, "+", VALUES(reason))');
    $stmt = $pdo->query('SELECT id, email, created_at, updated_at, last_login_at FROM users ORDER BY id');

    $reasonCounts = [
        'impossible_email_domain' => 0,
        'stale_older_than_14_days' => 0,
        'both' => 0,
    ];
    $scanned = 0;

    foreach ($stmt as $user) {
        $scanned++;
        $userId = (int)$user['id'];
        $badDomain = impossible_email_domain((string)$user['email']);
        $lastActivity = max_datetime([
            $user['updated_at'] ?? null,
            $user['last_login_at'] ?? null,
            $favoriteLast[$userId] ?? null,
            $bingeLast[$userId] ?? null,
            $syncLast[$userId] ?? null,
            $user['created_at'] ?? null,
        ]);
        $stale = $lastActivity !== null && $lastActivity < $cutoff;

        if ($badDomain || $stale) {
            if ($badDomain && $stale) {
                $reason = 'both';
                $reasonCounts['both']++;
            } elseif ($badDomain) {
                $reason = 'bad_domain';
                $reasonCounts['impossible_email_domain']++;
            } else {
                $reason = 'stale';
                $reasonCounts['stale_older_than_14_days']++;
            }
            $insert->execute([$userId, $reason]);
        }
    }

    return [
        'cutoff' => $cutoff,
        'scanned_users' => $scanned,
        'reason_counts' => $reasonCounts,
    ];
}

function collect_report(PDO $pdo, string $mode, array $context): array
{
    $candidates = scalar($pdo, 'SELECT COUNT(*) FROM tmp_cleanup_users');
    $favorites = scalar($pdo, 'SELECT COUNT(*) FROM favorites_backups f INNER JOIN tmp_cleanup_users c ON c.id = f.user_id');
    $binge = scalar($pdo, 'SELECT COUNT(*) FROM binge_state b INNER JOIN tmp_cleanup_users c ON c.id = b.user_id');
    $sync = scalar($pdo, 'SELECT COUNT(*) FROM sync_log s INNER JOIN tmp_cleanup_users c ON c.id = s.user_id');

    return [
        'success' => true,
        'mode' => $mode,
        'cutoff' => $context['cutoff'],
        'scanned_users' => $context['scanned_users'],
        'reason_counts' => $context['reason_counts'],
        'users_to_delete' => $candidates,
        'related_rows_to_delete' => [
            'favorites_backups' => $favorites,
            'binge_state' => $binge,
            'sync_log' => $sync,
        ],
    ];
}

try {
    $pdo = db();
    $context = prepare_candidates($pdo);
    $mode = (string)($_GET['mode'] ?? 'preview');

    if ($mode !== 'execute') {
        echo json_encode(collect_report($pdo, 'preview', $context), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $before = collect_report($pdo, 'execute', $context);
    $deleted = [];
    $pdo->beginTransaction();
    try {
        foreach (['favorites_backups', 'binge_state', 'sync_log'] as $table) {
            $stmt = $pdo->prepare("DELETE t FROM {$table} t INNER JOIN tmp_cleanup_users c ON c.id = t.user_id");
            $stmt->execute();
            $deleted[$table] = $stmt->rowCount();
        }
        $stmt = $pdo->prepare('DELETE u FROM users u INNER JOIN tmp_cleanup_users c ON c.id = u.id');
        $stmt->execute();
        $deleted['users'] = $stmt->rowCount();
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    $afterContext = prepare_candidates($pdo);
    $after = collect_report($pdo, 'after', $afterContext);

    echo json_encode([
        'success' => true,
        'started_at' => gmdate('c'),
        'before' => $before,
        'deleted' => $deleted,
        'after' => $after,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
