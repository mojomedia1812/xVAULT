import sys
from os import path

import xbmcvfs

from resources.lib import control
from resources.lib.tools import cParser

sysaddon = sys.argv[0]
syshandle = int(sys.argv[1]) if len(sys.argv) > 1 else ''
artPath = control.artPath()
addonFanart = control.addonFanart()

class navigator:
	def root(self):
		self.addDirectoryItem('Mein xVAULT', 'personalHome', 'DefaultRecentlyAddedEpisodes.png', 'DefaultTVShows.png')
		try:
			from resources.lib import personal
			personal.render_preview()
			personal.request_refresh()
		except Exception as exc:
			from resources.lib import log_utils
			log_utils.log('xVAULT Startbereich: ' + type(exc).__name__, log_utils.LOGWARNING)
		from resources.lib import distribution
		status = distribution.cached_status()
		if status and (status.get('kodibox', {}).get('detected') or status.get('version_warning') or status.get('integrity', {}).get('state') in ('modified', 'invalid_reference')):
			self.addDirectoryItem('[COLOR orange]' + status['summary'] + '[/COLOR]', 'distributionStatus', 'DefaultAddonProgram.png', 'DefaultAddonProgram.png', isFolder=False)
		self.addDirectoryItem("Suche Filme", 'moviesSearch', '01_suche_filme.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Suche TV-Serien", 'tvshowsSearch', '02_suche_tv_serien.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Suche nach Person / Darsteller", 'personSearch', '03_darsteller_suche_nach_person.png', 'DefaultAddonsSearch.png')
		self.addDirectoryItem("Collections", 'collectionsNavigator', '04_filme.png', 'DefaultMovies.png')
		self.addDirectoryItem("Filme", 'movieNavigator', '04_filme.png', 'DefaultMovies.png')
		self.addDirectoryItem("TV-Serien", 'tvNavigator', '05_tv_serien.png', 'DefaultTVShows.png')
		self.addDirectoryItem("LIVE-TV", 'liveTVNavigator', 'DefaultTVShows.png', 'DefaultTVShows.png')
		self.addDirectoryItem("LiveTV lite", 'liveTVLiteNavigator', 'DefaultTVShows.png', 'DefaultTVShows.png')
		if control.getSetting('radio.enabled', 'true') != 'false':
			self.addDirectoryItem("Radio", 'radioNavigator', 'DefaultMusicSources.png', 'DefaultMusicSources.png')
		self.addDirectoryItem("Werkzeuge", 'toolNavigator', '06_werkzeuge.png', 'DefaultAddonProgram.png')
		self._endDirectory(content='', cache=False)

	def movies(self):
		self.addDirectoryItem("[B]Filme[/B] - Neu", 'listings&media_type=movie&url=kino', '04_01_filme_neu.png', 'DefaultRecentlyAddedMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Jahr", 'movieYears', '04_02_filme_jahr.png', 'DefaultMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Genres", 'movieGenres', '04_03_filme_genres.png', 'DefaultMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Streaming-Anbieter", 'movieWatchProviders', 'tmdb_search.png', 'DefaultMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Am populärsten", 'listings&media_type=movie&url=production_status=released%26sort_by=popularity.desc', '04_04_filme_am_populaersten.png', 'DefaultMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Am besten bewertet", 'listings&media_type=movie&url=production_status=released%26sort_by=vote_average.desc', '04_05_filme_am_besten_bewertet.png', 'DefaultMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Meist bewertet", 'listings&media_type=movie&url=production_status=released%26sort_by=vote_count.desc', '04_06_filme_meist_bewertet.png', 'DefaultMovies.png')
		self.addDirectoryItem("[B]Filme[/B] - Bestes Einspielergebnis", 'listings&media_type=movie&url=production_status=released%26sort_by=revenue.desc', '04_07_filme_bestes_einspielergebnis.png', 'DefaultMovies.png')
		if control.getSetting('trakt.watchlist.menu', 'true') == 'true':
			self.addDirectoryItem("[B]Trakt[/B] - Watchlist Filme", 'traktList&type=watchlist&media_type=movie', '04_filme.png', 'DefaultMovies.png')
		if control.getSetting('trakt.collection.menu', 'true') == 'true':
			self.addDirectoryItem("[B]Trakt[/B] - Collection Filme", 'traktList&type=collection&media_type=movie', '04_filme.png', 'DefaultMovies.png')
		self._endDirectory()

	def tvshows(self):
		self.addDirectoryItem("[B]Serien[/B] - Neue Serien", 'listings&media_type=tv&url=new_tv_de', '05_tv_serien.png', 'DefaultTVShows.png')
		self.addDirectoryItem("[B]Serien[/B] - Genres", 'tvGenres', '05_01_serien_genres.png', 'DefaultTVShows.png')
		self.addDirectoryItem("[B]Serien[/B] - Streaming-Anbieter", 'tvWatchProviders', 'tmdb_search.png', 'DefaultTVShows.png')
		self.addDirectoryItem("[B]Serien[/B] - Am populärsten", 'listings&media_type=tv&url=sort_by=popularity.desc', '05_02_serien_am_populaersten.png', 'DefaultTVShows.png')
		self.addDirectoryItem("[B]Serien[/B] - Am besten bewertet", 'listings&media_type=tv&url=sort_by=vote_average.desc', '05_03_serien_am_besten_bewertet.png', 'DefaultTVShows.png')
		self.addDirectoryItem("[B]Serien[/B] - Meist bewertet", 'listings&media_type=tv&url=sort_by=vote_count.desc', '05_04_serien_meist_bewertet.png', 'DefaultTVShows.png')
		trakt_connected = self._traktConnected()
		if trakt_connected and control.getSetting('trakt.watchlist.menu', 'true') == 'true':
			self.addDirectoryItem("[B]Trakt[/B] - Watchlist Serien", 'traktList&type=watchlist&media_type=tv', '05_tv_serien.png', 'DefaultTVShows.png')
		if trakt_connected and control.getSetting('trakt.collection.menu', 'true') == 'true':
			self.addDirectoryItem("[B]Trakt[/B] - Collection Serien", 'traktList&type=collection&media_type=tv', '05_tv_serien.png', 'DefaultTVShows.png')
		self._endDirectory()

	def tools(self):
		self.addDirectoryItem('Einstellungen', 'toolSettingsNavigator', '06_02_xvault_einstellungen.png', 'DefaultAddonProgram.png',
			description='xVAULT einrichten, Anbieter-Zugänge verwalten und erweiterte ResolveURL-Einstellungen öffnen.')
		self.addDirectoryItem('Updates und Version', 'toolUpdatesNavigator', '06_werkzeuge.png', 'DefaultAddonProgram.png',
			description='Installierte Version und Originalstatus prüfen, Updates suchen und den Update-Kanal auswählen.')
		self.addDirectoryItem('Hilfe und Problembehebung', 'toolHelpNavigator', '06_01_support_informationen_anzeigen.png', 'DefaultAddonProgram.png',
			description='Systeminformationen anzeigen, Einstellungen auf Fehler prüfen und ein Diagnosepaket für den Support erstellen.')
		self._endDirectory(category='Werkzeuge', cache=False)

	def tools_settings(self):
		self.addDirectoryItem('xVAULT-Einstellungen öffnen', 'addonSettings', '06_02_xvault_einstellungen.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Öffnet alle xVAULT-Einstellungen, darunter Wiedergabe, Quellen, Konten und Synchronisation, Radio und Datenschutz.')
		self.addDirectoryItem('Anbieter-Zugänge verwalten', 'providerLoginsNavigator', '06_02_xvault_einstellungen.png', 'DefaultAddonProgram.png',
			description='Zugangsdaten für FlimmerStube, AniWorld und OpenSubtitles eingeben, ändern oder nach Bestätigung löschen.')
		self.addDirectoryItem('ResolveURL-Einstellungen (erweitert)', 'resolverSettings', '06_03_resolver_einstellungen.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Öffnet die technischen Einstellungen des separaten ResolveURL-Add-ons zur Auflösung von Streamquellen.')
		self._endDirectory(category='Werkzeuge / Einstellungen', cache=False)

	def tools_updates(self):
		from resources.lib import updater
		channel = 'Nightly' if updater.selected_channel() == 'nightly' else 'Release'
		self.addDirectoryItem('Version und Originalstatus anzeigen', 'distributionStatus', '06_01_support_informationen_anzeigen.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Zeigt installierte Version, Originalprüfung, Update-Status und Supportstatus an.')
		self.addDirectoryItem('Nach Updates suchen', 'updateCheck', '06_werkzeuge.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Prüft jetzt, welche Version im gewählten Update-Kanal verfügbar ist. Diese Prüfung startet selbst keine Installation.')
		self.addDirectoryItem('Update-Kanal wählen: ' + channel, 'updateChannel', '06_werkzeuge.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Aktuell: %s. Zwischen freigegebenen Release-Versionen und Nightly-Testversionen wechseln. Ein Kanalwechsel wird bestätigt.' % channel)
		self.addDirectoryItem('xVAULT aktualisieren oder reparieren …', 'updateInstall', '06_werkzeuge.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Installiert nach Bestätigung das angebotene Originalpaket des gewählten Kanals. Eine erneute Installation kann veränderte oder beschädigte Add-on-Dateien ersetzen.')
		self._endDirectory(category='Werkzeuge / Updates und Version', cache=False)

	def tools_help(self):
		self.addDirectoryItem('Systemcheck und passende Hilfen', 'systemCheck', 'DefaultAddonProgram.png', 'DefaultAddonProgram.png')
		self.addDirectoryItem('System- und Supportinformationen anzeigen', 'pluginInfo', '06_01_support_informationen_anzeigen.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Zeigt technische Informationen zu Kodi, System, xVAULT, ResolveURL, TMDbHelper und Netzwerk für die Fehlersuche an.')
		self.addDirectoryItem('Einstellungen auf Fehler prüfen …', 'repairSettings', '06_02_xvault_einstellungen.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Prüft, ob die gespeicherte Einstellungsdatei lesbar ist. Nur bei einem Schaden wird nach Bestätigung eine Sicherung und ein Zurücksetzen angeboten.')
		self.addDirectoryItem('Diagnosepaket erstellen und hochladen …', 'supportUpload', '06_01_support_informationen_anzeigen.png', 'DefaultAddonProgram.png', isFolder=False,
			description='Erstellt ein bereinigtes Diagnosepaket und zeigt dessen Zusammenfassung. Der Upload startet erst nach deiner Bestätigung; anschließend erhältst du eine Support-ID.')
		self._endDirectory(category='Werkzeuge / Hilfe und Problembehebung', cache=False)

	def provider_logins(self):
		from resources.lib import provider_logins
		for provider_id, provider_name in provider_logins.provider_items():
			configured = provider_logins.is_configured(provider_id)
			status = 'Eingerichtet' if configured else 'Nicht eingerichtet'
			action = 'Zugangsdaten ändern' if configured else 'Zugangsdaten eingeben'
			self.addDirectoryItem(
				'%s: %s – %s' % (provider_name, action, status),
				'providerLogin&provider=%s' % provider_id,
				'06_02_xvault_einstellungen.png',
				'DefaultAddonProgram.png',
				isFolder=False,
				description='%s: %s. Öffnet die Eingabe der Zugangsdaten; die Eingabe kann abgebrochen werden.' % (provider_name, status),
			)
			self.addDirectoryItem(
				'%s: Zugangsdaten löschen …' % provider_name,
				'providerLoginClear&provider=%s' % provider_id,
				'06_02_xvault_einstellungen.png',
				'DefaultAddonProgram.png',
				isFolder=False,
				description='Entfernt die gespeicherten Zugangsdaten für %s erst nach Bestätigung.' % provider_name,
			)
		self._endDirectory(category='Werkzeuge / Einstellungen / Anbieter-Zugänge', cache=False)

	def downloads(self):
		movie_downloads = control.getSetting('download.movie.path')
		tv_downloads = control.getSetting('download.tv.path')
		if len(control.listDir(movie_downloads)[0]) > 0:
			self.addDirectoryItem("Filme", movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
		if len(control.listDir(tv_downloads)[0]) > 0:
			self.addDirectoryItem("TV-Serien", tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
		self._endDirectory()

	def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True, description=None):
		url = '%s?action=%s' % (sysaddon, query) if isAction else query
		thumb = self.getMedia(thumb, icon)
		listitem = control.item(name, offscreen=True)
		listitem.setArt({'poster': thumb, 'icon': icon})
		if context is not None:
			cm = []
			cm.append((context[0], 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
			listitem.addContextMenuItems(cm)

		isMatch, sPlot = cParser.parseSingleResult(query, "plot'.*?'([^']+)")
		if not isMatch: sPlot = '[COLOR blue]{0}[/COLOR]'.format(name)
		if description is not None: sPlot = description
		info = {'plot': control.unquote_plus(sPlot)}
		if isFolder: info['overlay'] = 4
		listitem.setInfo('video', info)
		if isFolder:
			listitem.setIsFolder(True)
		else:
			listitem.setProperty('IsPlayable', 'false')
		self.addFanart(listitem, query)
		control.addItem(syshandle, url, listitem, isFolder)

	def _traktConnected(self):
		try:
			from resources.lib import trakt
			return trakt.is_connected()
		except:
			return False

	def _endDirectory(self, content='', cache=True, category=None):
		control.content(syshandle, content)
		control.plugincategory(syshandle, control.addonName + ' / ' + (category or control.addonVersion))
		control.endofdirectory(syshandle, succeeded=True, cacheToDisc=cache)

	def addFanart(self, listitem, query):
		if control.getSetting('fanart')=='true':
			isMatch, sFanart = cParser.parseSingleResult(query, "fanart'.*?'([^']+)")
			if isMatch:
				sFanart = self.getMedia(sFanart)
				listitem.setProperty('fanart_image', sFanart)
			else:
				listitem.setProperty('fanart_image', addonFanart)

	def getMedia(self,mediaFile=None, icon=None):
		if xbmcvfs.exists(path.join(artPath, mediaFile)): mediaFile = path.join(artPath, mediaFile)
		elif xbmcvfs.exists(path.join(artPath, 'sites', mediaFile)): mediaFile = path.join(artPath, 'sites', mediaFile)
		elif mediaFile.startswith('http'): return mediaFile
		else: mediaFile = icon
		return mediaFile
	

