# -*- coding: UTF-8 -*-
import base64
import hashlib
import json
import os
import re
import time
import urllib.parse
import urllib.request

from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib.tools import logger

SITE_IDENTIFIER = 'vixstream'
SITE_DOMAIN = 'vixsrc.to'
SITE_NAME = SITE_IDENTIFIER.upper()
_K = base64.b64decode('ZWRkZTZiNWU0MTI0NmFiNzlhMjY5N2NkMTI1ZTE3ODE=').decode()
KEY_URI_RE = re.compile(r'URI=(?:"([^"]+)"|([^,\s]+))', flags=re.I)


class source:
    def __init__(self):
        self.priority = 1
        self.cache_version = 1
        self.language = ['de', 'en']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.tak = getSetting('api.tmdb') or _K
        self.ua = (
            'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 '
            '(KHTML, like Gecko) SamsungBrowser/29.0 Chrome/136.0.0.0 Mobile Safari/537.36'
        )
        self.sources = []

    def _request(self, url, headers=None, caching=False, preserve_newlines=False):
        request = cRequestHandler(url, caching=caching, ignoreErrors=True)
        if preserve_newlines:
            request.removeNewLines(False)
            request.removeBreakLines(False)
        request.addHeaderEntry('User-Agent', self.ua)
        request.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
        for key, value in (headers or {}).items():
            request.addHeaderEntry(key, value)
        payload = request.request()
        return payload, str(request.getStatus()), request.getRealUrl()

    def _request_json(self, url, headers=None, caching=False):
        payload, status, real_url = self._request(url, headers=headers, caching=caching)
        if status not in ['200', '301']:
            if status == '404':
                logger.info('[%s] API-Status: %s' % (SITE_NAME, status))
            else:
                logger.warning('[%s] API-Status: %s' % (SITE_NAME, status))
            return None
        try:
            return json.loads(payload)
        except Exception as exc:
            logger.error('[%s] JSON-Fehler: %s' % (SITE_NAME, str(exc)))
            return None

    def _request_bytes(self, url, headers=None, timeout=12):
        request = urllib.request.Request(url, headers=headers or {})
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.read()

    def _get_tmdb_id(self, imdb_id):
        try:
            url = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % (imdb_id, self.tak)
            oRequest = cRequestHandler(url, caching=True)
            data = json.loads(oRequest.request())
            if data.get('movie_results'):
                return str(data['movie_results'][0]['id'])
            if data.get('tv_results'):
                return str(data['tv_results'][0]['id'])
        except Exception as exc:
            logger.error('[%s] TMDB Fehler: %s' % (SITE_NAME, str(exc)))
        return None

    def _stream_languages(self):
        setting = getSetting('hosts.language') or '0'
        if setting == '1':
            return [('de', 'Deutsch')]
        if setting == '2':
            return [('en', 'Englisch')]
        return [('de', 'Deutsch'), ('en', 'Englisch')]

    def _src_with_language(self, src, language):
        if re.search(r'([?&])lang=[a-z]+', src):
            return re.sub(r'([?&])lang=[a-z]+', r'\1lang=%s' % language, src)
        separator = '&' if '?' in src else '?'
        return '%s%slang=%s' % (src, separator, language)

    def _language_headers(self, stream_language, referer=''):
        headers = {
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8' if stream_language == 'de' else 'en-US,en;q=0.9,de;q=0.7',
        }
        if referer:
            headers['Referer'] = referer
        return headers

    def _media_urls(self, tmdb_id, season=0, episode=0):
        is_tvshow = getattr(self, 'mediatype', None) == 'tvshow'
        if int(season) == 0 and not is_tvshow:
            page_url = 'https://%s/movie/%s' % (self.domain, tmdb_id)
            api_url = 'https://%s/api/movie/%s' % (self.domain, tmdb_id)
            media_type = 'movie'
        else:
            page_url = 'https://%s/tv/%s/%s/%s' % (self.domain, tmdb_id, str(season), str(episode))
            api_url = 'https://%s/api/tv/%s/%s/%s' % (self.domain, tmdb_id, str(season), str(episode))
            media_type = 'tv'
        return media_type, page_url, api_url

    def _stable_url(self, tmdb_id, season=0, episode=0, language='de'):
        if int(season) == 0 and getattr(self, 'mediatype', None) != 'tvshow':
            return 'vixsrc://movie/%s?lang=%s' % (tmdb_id, language)
        return 'vixsrc://tv/%s/%s/%s?lang=%s' % (tmdb_id, int(season), int(episode), language)

    def _visit_page_for_cookies(self, page_url):
        try:
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
            payload, status, real_url = self._request(page_url, headers=headers, caching=False)
            logger.info('[%s] Seite besucht: %s - Status: %s' % (SITE_NAME, page_url, status))
            return status in ['200', '301']
        except Exception as exc:
            logger.error('[%s] Fehler beim Seitenbesuch: %s' % (SITE_NAME, str(exc)))
            return False

    def _fresh_embed_url(self, tmdb_id, season=0, episode=0, language='de'):
        media_type, page_url, api_url = self._media_urls(tmdb_id, season, episode)
        self._visit_page_for_cookies(page_url)

        headers = {
            'Referer': page_url,
            'Accept': 'application/json, */*',
            'Origin': 'https://' + self.domain,
            'Connection': 'keep-alive'
        }
        data = self._request_json(api_url, headers=headers, caching=False)
        if not data:
            return None, None
        src = data.get('src', '')
        if not src:
            logger.warning('[%s] Kein src in API-Response gefunden' % SITE_NAME)
            return None, None

        embed_url = urllib.parse.urljoin(
            'https://%s/' % self.domain,
            self._src_with_language(src, language).lstrip('/')
        )
        logger.info('[%s] Frischer Embed: type=%s tmdb=%s lang=%s' % (SITE_NAME, media_type, tmdb_id, language))
        return embed_url, page_url

    def _playlist_from_embed(self, embed_url, referer, stream_language):
        headers = {
            'Referer': referer,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        }
        headers.update(self._language_headers(stream_language))

        html, status, real_url = self._request(embed_url, headers=headers, caching=False)
        if status not in ['200', '301']:
            logger.error('[%s] Embed Status: %s' % (SITE_NAME, status))
            return None, None, None

        token_match = re.search(r"['\"]token['\"]?\s*:\s*['\"]([a-f0-9]+)['\"]", html)
        expires_match = re.search(r"['\"]expires['\"]?\s*:\s*['\"]?(\d+)['\"]?", html)
        url_match = re.search(r"url\s*:\s*['\"]([^'\"]+/playlist/\d+(?:\?[^'\"]*)?)['\"]", html)

        if not (token_match and expires_match and url_match):
            logger.error('[%s] Playlist-Parameter unvollstaendig: token=%s expires=%s url=%s' % (
                SITE_NAME, bool(token_match), bool(expires_match), bool(url_match)
            ))
            return None, None, None

        playlist_base = url_match.group(1).replace('\\/', '/')
        separator = '&' if '?' in playlist_base else '?'
        playlist_url = '%s%stoken=%s&expires=%s&h=1&lang=%s' % (
            playlist_base,
            separator,
            token_match.group(1),
            expires_match.group(1),
            stream_language
        )
        embed_parts = urllib.parse.urlparse(embed_url)
        embed_origin = '%s://%s' % (embed_parts.scheme, embed_parts.netloc)
        playlist_headers = {
            'User-Agent': self.ua,
            'Accept': '*/*',
            'Referer': embed_url,
            'Origin': embed_origin,
        }
        playlist_headers.update(self._language_headers(stream_language))

        playlist, playlist_status, real_playlist_url = self._request(
            playlist_url,
            headers=playlist_headers,
            caching=False,
            preserve_newlines=True
        )
        if playlist_status not in ['200', '301']:
            logger.error('[%s] Playlist Status: %s' % (SITE_NAME, playlist_status))
            return playlist_url, playlist_headers, None

        return playlist_url, playlist_headers, playlist

    def _verified_stream_language(self, tmdb_id, season, episode, stream_language):
        embed_url, referer = self._fresh_embed_url(tmdb_id, season, episode, stream_language)
        if not embed_url:
            return None, None, None, 'SD'

        playlist_url, playlist_headers, playlist = self._playlist_from_embed(embed_url, referer, stream_language)
        if not playlist:
            logger.warning('[%s] Sprache nicht verifiziert: lang=%s tmdb=%s' % (SITE_NAME, stream_language, tmdb_id))
            return None, None, None, 'SD'

        valid, audio_languages, quality = self._inspect_playlist(playlist_url, playlist_headers, playlist)
        if not valid:
            return None, None, None, 'SD'
        known_languages = audio_languages - {'unknown'}
        if known_languages and stream_language not in known_languages:
            logger.info('[%s] Sprache verworfen: angefordert=%s, Audio=%s, tmdb=%s' % (
                SITE_NAME, stream_language, ','.join(sorted(audio_languages)), tmdb_id
            ))
            return None, None, None, quality

        if stream_language in known_languages:
            logger.info('[%s] Sprache verifiziert: lang=%s, Audio=%s, tmdb=%s' % (
                SITE_NAME, stream_language, ','.join(sorted(audio_languages)), tmdb_id
            ))
        return embed_url, playlist_url, audio_languages, quality

    def _inspect_playlist(self, playlist_url, headers, playlist, depth=0, visited=None):
        """Validate nested HLS manifests; a requested lang is not audio evidence."""
        if isinstance(playlist, bytes):
            playlist = playlist.decode('utf-8', 'replace')
        playlist = (playlist or '').lstrip('\ufeff \r\n\t')
        if not playlist.startswith('#EXTM3U'):
            return False, set(), 'SD'
        languages = self._audio_languages_from_playlist(playlist)
        heights = [int(h) for h in re.findall(r'RESOLUTION\s*=\s*\d+x(\d+)', playlist, re.I)]
        height = max(heights or [0])
        quality = next((q for limit, q in [(2160, '4K'), (1080, '1080p'), (720, '720p')] if height >= limit), 'SD')
        lines = [line.strip() for line in playlist.splitlines() if line.strip()]
        media = [line for line in lines if not line.startswith('#')]
        if not media:
            return False, languages, quality
        if any(line.startswith('#EXTINF:') for line in lines):
            return True, languages, quality
        if not any(line.startswith('#EXT-X-STREAM-INF:') for line in lines) or depth >= 2:
            return False, languages, quality
        child_url = urllib.parse.urljoin(playlist_url, media[0])
        if urllib.parse.urlsplit(child_url).scheme not in ('http', 'https'):
            return False, languages, quality
        visited = set(visited or ()) | {playlist_url}
        if child_url in visited:
            return False, languages, quality
        child, status, real_url = self._request(child_url, headers=headers, caching=False, preserve_newlines=True)
        if status not in ('200', '301'):
            return False, languages, quality
        valid, child_languages, child_quality = self._inspect_playlist(
            real_url or child_url, headers, child, depth + 1, visited)
        return valid, languages or child_languages, quality if heights else child_quality

    def _audio_languages_from_playlist(self, playlist):
        languages = set()
        audio_seen = False
        if isinstance(playlist, bytes):
            playlist = playlist.decode('utf-8', 'replace')
        media_lines = re.findall(r'#EXT-X-MEDIA:[^#\r\n]+', playlist or '', flags=re.I)
        if not media_lines:
            media_lines = (playlist or '').splitlines()
        for line in media_lines:
            if not re.search(r'#EXT-X-MEDIA', line or '', flags=re.I):
                continue
            if not re.search(r'TYPE\s*=\s*AUDIO', line or '', flags=re.I):
                continue
            audio_seen = True
            code = self._audio_language_from_values(
                self._hls_attr(line, 'LANGUAGE'),
                self._hls_attr(line, 'NAME'),
                self._hls_attr(line, 'RENDITION')
            )
            if code:
                languages.add(code)
        if audio_seen and not languages:
            languages.add('unknown')
        return languages

    @staticmethod
    def _hls_attr(line, name):
        match = re.search(r'%s=(?:"([^"]*)"|([^,]*))' % re.escape(name), line or '', flags=re.I)
        if not match:
            return ''
        return (match.group(1) if match.group(1) is not None else match.group(2) or '').strip()

    @staticmethod
    def _audio_language_from_values(*values):
        text = ' '.join([str(value or '') for value in values]).lower()
        text = re.sub(r'[^a-z0-9]+', ' ', text)
        tokens = set([token for token in text.split() if token])
        if tokens.intersection(set(['de', 'deu', 'ger', 'german', 'deutsch'])):
            return 'de'
        if tokens.intersection(set(['en', 'eng', 'english', 'englisch'])):
            return 'en'
        return ''

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            tmdb_id = self._get_tmdb_id(imdb)
            if not tmdb_id:
                logger.warning('[%s] Keine TMDB-ID gefunden fuer IMDB: %s' % (SITE_NAME, imdb))
                return self.sources

            seen_urls = set()
            for language, language_label in self._stream_languages():
                embed_url, playlist_url, audio_languages, quality = self._verified_stream_language(tmdb_id, season, episode, language)
                if not embed_url:
                    continue

                verified_language = language if language in audio_languages else 'unknown'
                stable_url = self._stable_url(tmdb_id, season, episode, language)
                dedup_key = verified_language
                if dedup_key in seen_urls:
                    continue
                seen_urls.add(dedup_key)

                self.sources.append({
                    'source': 'VixCloud',
                    'quality': quality,
                    'language': verified_language,
                    'url': stable_url,
                    'direct': False,
                    'info': language_label if verified_language != 'unknown' else 'Sprache unbekannt'
                })
                if getattr(self, 'mediatype', None) != 'tvshow' and not season:
                    # The stream's TMDb ID was obtained by the successful IMDb lookup.
                    self.sources[-1]['movie_identity'] = {'imdb': imdb}
                logger.info('[%s] Quelle gefunden: tmdb=%s, lang=%s' % (SITE_NAME, tmdb_id, language))

        except Exception as exc:
            logger.error('[%s] run() Fehler: %s' % (SITE_NAME, str(exc)))
            import traceback
            logger.debug('[%s] Traceback: %s' % (SITE_NAME, traceback.format_exc()))

        return self.sources

    def _resolve_stable_url(self, url_data):
        parsed = urllib.parse.urlparse(url_data)
        query = urllib.parse.parse_qs(parsed.query)
        stream_language = query.get('lang', ['de'])[0]
        if stream_language not in ['de', 'en']:
            stream_language = 'de'

        parts = [part for part in parsed.path.strip('/').split('/') if part]
        if parsed.netloc == 'movie' and len(parts) >= 1:
            embed_url, referer = self._fresh_embed_url(parts[0], 0, 0, stream_language)
            return embed_url, referer, stream_language

        if parsed.netloc == 'tv' and len(parts) >= 3:
            tmdb_id, season, episode = parts[:3]
            embed_url, referer = self._fresh_embed_url(tmdb_id, season, episode, stream_language)
            return embed_url, referer, stream_language

        logger.error('[%s] Ungueltige stabile URL: %s' % (SITE_NAME, url_data))
        return None, None, stream_language

    def resolve(self, url_data):
        try:
            if url_data.startswith('vixsrc://'):
                embed_url, referer, stream_language = self._resolve_stable_url(url_data)
                if not embed_url:
                    return None
            else:
                embed_url, referer = url_data.split('|', 1)
                parsed_embed = urllib.parse.urlparse(embed_url)
                stream_language = urllib.parse.parse_qs(parsed_embed.query).get('lang', ['de'])[0]
                if stream_language not in ['de', 'en']:
                    stream_language = 'de'

            logger.info('[%s] resolve() - embed_url: %s' % (SITE_NAME, embed_url))
            playlist_url, headers_dict, playlist = self._playlist_from_embed(embed_url, referer, stream_language)
            if not playlist_url or not headers_dict or not playlist:
                return None

            valid, audio_languages, quality = self._inspect_playlist(playlist_url, headers_dict, playlist)
            if not valid:
                return None
            known_languages = audio_languages - {'unknown'}
            if known_languages and stream_language not in known_languages:
                logger.error('[%s] Resolve abgebrochen: angefordert=%s, Audio=%s' % (
                    SITE_NAME, stream_language, ','.join(sorted(audio_languages))
                ))
                return None

            playlist_url = self._local_hls_playlist_url(playlist_url, headers_dict, playlist) or playlist_url
            final_url = '%s|%s' % (playlist_url, urllib.parse.urlencode(headers_dict))
            logger.info('[%s] Finale URL: %s' % (SITE_NAME, final_url[:150]))
            return final_url

        except Exception as exc:
            logger.error('[%s] resolve() Fehler: %s' % (SITE_NAME, str(exc)))
            import traceback
            logger.debug('[%s] Traceback: %s' % (SITE_NAME, traceback.format_exc()))
            return None

    def _local_hls_playlist_url(self, playlist_url, headers_dict, playlist):
        try:
            if not playlist or '#EXT-X-KEY' not in playlist:
                return None

            cache_dir = self._hls_cache_dir()
            self._cleanup_hls_cache(cache_dir)

            key_files = {}
            for key_uri in self._key_uris_from_playlist(playlist):
                key_url = urllib.parse.urljoin(playlist_url, key_uri)
                key_data = self._request_bytes(key_url, headers=headers_dict)
                if not key_data:
                    return None
                key_name = 'key_%s.bin' % hashlib.sha256(key_url.encode('utf-8')).hexdigest()[:20]
                key_path = os.path.join(cache_dir, key_name)
                with open(key_path, 'wb') as handle:
                    handle.write(key_data)
                key_files[key_uri] = self._file_url(key_path)

            rewritten = self._rewrite_hls_playlist(playlist_url, playlist, key_files)
            playlist_name = 'playlist_%s.m3u8' % hashlib.sha256((playlist_url + str(time.time())).encode('utf-8')).hexdigest()[:20]
            playlist_path = os.path.join(cache_dir, playlist_name)
            with open(playlist_path, 'w', encoding='utf-8', newline='\n') as handle:
                handle.write(rewritten)
            logger.info('[%s] Lokale HLS-Playlist vorbereitet' % SITE_NAME)
            return self._file_url(playlist_path)
        except Exception as exc:
            logger.warning('[%s] Lokale HLS-Playlist nicht nutzbar: %s' % (SITE_NAME, str(exc)))
            return None

    def _hls_cache_dir(self):
        try:
            from resources.lib import control
            base = control.addonProfilePath
        except:
            base = os.path.join(os.getcwd(), 'xvault_profile')
        cache_dir = os.path.join(base, 'vixstream_hls')
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        return cache_dir

    def _cleanup_hls_cache(self, cache_dir, max_age=6 * 60 * 60):
        try:
            now = time.time()
            for name in os.listdir(cache_dir):
                path = os.path.join(cache_dir, name)
                if os.path.isfile(path) and now - os.path.getmtime(path) > max_age:
                    os.remove(path)
        except:
            pass

    def _key_uris_from_playlist(self, playlist):
        uris = []
        for line in playlist.splitlines():
            if not line.startswith('#EXT-X-KEY'):
                continue
            match = KEY_URI_RE.search(line)
            if not match:
                continue
            uri = match.group(1) if match.group(1) is not None else match.group(2)
            if uri and uri not in uris:
                uris.append(uri)
        return uris

    def _rewrite_hls_playlist(self, playlist_url, playlist, key_files):
        lines = []
        for line in playlist.splitlines():
            stripped = line.strip()
            if stripped.startswith('#EXT-X-KEY'):
                line = self._rewrite_hls_uri_attr(line, playlist_url, key_files)
            elif stripped.startswith('#EXT-X-MEDIA') and 'URI=' in stripped:
                line = self._rewrite_hls_uri_attr(line, playlist_url, key_files)
            elif stripped and not stripped.startswith('#'):
                line = urllib.parse.urljoin(playlist_url, stripped)
            lines.append(line)
        return '\n'.join(lines) + '\n'

    def _rewrite_hls_uri_attr(self, line, playlist_url, key_files):
        def repl(match):
            uri = match.group(1) if match.group(1) is not None else match.group(2)
            target = key_files.get(uri) or urllib.parse.urljoin(playlist_url, uri)
            return 'URI="%s"' % target
        return KEY_URI_RE.sub(repl, line)

    @staticmethod
    def _file_url(path):
        path = os.path.abspath(path).replace('\\', '/')
        if re.match(r'^[A-Za-z]:/', path):
            return 'file:///' + path
        return 'file://' + path
